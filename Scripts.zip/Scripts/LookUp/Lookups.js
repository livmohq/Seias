﻿
function GetDisplayOrder(Div) {
    var listItems = "";
    listItems += '<select   id="' + Div.replace('Div', 'Id') + '"  class="select2_group form-control"   tabindex="-1"  placeholder="Select Vehicle Portals"><option value=""></option>';
    for (i = 0; i <= 10; i++) {
        listItems += '<option value=' + i + '>' + i + ' </option>';
    }
    listItems += '</select>';
    $('#' + Div).append(listItems);
}
function GetAllSubsectionDiv(_obj, QustionnaireId ) {
    Div = _obj + '_SubsectionDiv'; 
    var obj = {};
    obj.QustionnaireId = document.getElementById('Qustionnaire_Id').innerHTML;
    $.ajax({

        type: "POST",
        url: "/Services/DataCollection.asmx/GetAllSubsectionByQustionnaireId"
        , contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: function (response) {
            $('#' + Div).empty();
            var object = response.d;
            var listItems = "";
            listItems += '<select   id="' + Div.replace('Div', 'Id') + '"     class="select2_group form-control"   tabindex="-1"  placeholder="Select Vehicle Portals"><option value="">None</option>';
            $.each(object, function (index, object) {
                listItems += '<option value=' + object.Uid + '>' + object.Name + ' </option>';
            });
            listItems += '</select>';
            $('#' + Div).append(listItems);
        },
        failure: function (msg) {
            $('#' + Div).text(msg);
        }
    });
}


function GetQustionnaireByDiv(_obj, AssessmentId) {
    var Div = _obj +'_QustionnaireDiv'
    

    var obj = {};
    obj.AssessmentId = AssessmentId;
    $.ajax({

        type: "POST",
        url: "/Services/DataCollection.asmx/GetQustionnaireByAssessmentId"
        , contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: function (response) {
            $('#' + Div).empty();
            var object = response.d;
            var listItems = "";
            listItems += '<select   id="' + Div.replace('Div', 'Id') + '" class="select2_group form-control"   tabindex="-1"  placeholder="Select Vehicle Portals"><option value="">None</option>';//onchange="GetQustionnaireByDiv(\'' + _obj +'\', this.options[this.selectedIndex].value)" 
            $.each(object, function (index, object) {
                listItems += '<option value=' + object.Uid + '>' + object.Name + ' </option>';
            });
            listItems += '</select>';
            $('#' + Div).append(listItems);
        },
        failure: function (msg) {
            $('#' + Div).text(msg);
        }
    });
}

function GetAllAspNetRolesDiv(Div) {

    var obj = {};
    $.ajax({
        type: "POST",
        data: JSON.stringify(obj),
        url: "/Services/DataCollection.asmx/GetAllAspNetRole",
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: function (response) {
            $('#' + Div).empty();
            var object = response.d;
            var listItems = "";
            listItems += '<select   id="' + Div.replace('Div', 'Id') + '" class="select2_group form-control" ><option value="">None</option>';
            $.each(object, function (index, object) {
                listItems += '<option value=' + object.Id + '>' + object.Name + ' </option>';
            });
            listItems += '</select>';
            $('#' + Div).append(listItems);
        },
        failure: function (msg) {
            $('#' + Div).text(msg);
        }
    });
};

function GetAllDepartmentDiv(Div) {

    var obj = {};
    $.ajax({
        type: "POST",
        data: JSON.stringify(obj),
        url: "/Services/DataCollection.asmx/GetAllDepartment",
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: function (response) {
            $('#' + Div).empty();
            var object = response.d;
            var listItems = "";
            listItems += '<select   id="' + Div.replace('Div', 'Id') + '" class="select2_group form-control" ><option value="">None</option>';
            $.each(object, function (index, object) {
                listItems += '<option value=' + object.Id + '>' + object.Name + ' </option>';
            });
            listItems += '</select>';
            $('#' + Div).append(listItems);
        },
        failure: function (msg) {
            $('#' + Div).text(msg);
        }
    });
};


//function GetApprovalUsersDiv(Div) {

//    var obj = {};
//    alert('Approval');
//    $.ajax({
//        type: "POST",
//        data: JSON.stringify(obj),
//        url: "/Services/DataCollection.asmx/GetAllAspNetApproval",
//        contentType: "application/json; charset=utf-8",
//        dataType: "json",
//        success: function (response) {
//            $('#' + Div).empty();
//            var object = response.d;
//            var listItems = "";
//            listItems += '<select   id="' + Div.replace('Div', 'Id') + '" class="select2_group form-control" ><option value="">None</option>';
//            $.each(object, function (index, object) {
//                listItems += '<option value=' + object.Id + '>' + object.Name + ' </option>';
//            });
//            listItems += '</select>';
//            $('#' + Div).append(listItems);
//        },
//        failure: function (msg) {
//            $('#' + Div).text(msg);
//        }
//    });
//};

function GetApprovalUsersDiv(_obj) {

    var Div = _obj + '_NameDiv';
    $.ajax({
        type: "POST",
        url: "/Services/DataCollection.asmx/GetAllAspNetApproval"
        , contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: function (response) {
            $('#' + Div).empty();
            var object = response.d;
            var listItems = "";
            listItems += '<select   id="' + Div.replace('Div', 'Id') + '" class="select2_group form-control"   tabindex="-1"  placeholder="Select Survey"><option value="">None</option>'; //onchange = "ViewSurveyReports(\'' + _obj + '\', this.options[this.selectedIndex].value)"
            //listItems += '<select   id="' + Div.replace('Div', 'Id') + '" onchange = "GetSurveyReportById(\'' + _Id + '\', this.options[this.selectedIndex].value)" class="select2_group form-control"   tabindex="-1"  placeholder="Select Survey"><option value="">None</option>';
            $.each(object, function (index, object) {
                listItems += '<option value=' + object.Id + '>' + object.Name + ' </option>';
            });
            listItems += '</select>';
            $('#' + Div).append(listItems);
        },
        failure: function (msg) {
            $('#' + Div).text(msg);
        }
    });
}


function GetActiveAssignmentDiv(_obj) {
    var Div = _obj + '_AssignmentDiv'; 
    $.ajax({
      type: "POST",
      url: "/Services/DataCollection.asmx/GetActiveListAssignment"
        , contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: function (response) {
            $('#' + Div).empty();
            var object = response.d;
            var listItems = "";
            listItems += '<select   id="' + Div.replace('Div', 'Id') + '"   class="select2_group form-control"   tabindex="-1"  placeholder="Select Vehicle Portals"><option value="">None</option>';//onchange="GetQustionnaireByDiv(\'' + _obj+'\', this.options[this.selectedIndex].value)" 
            $.each(object, function (index, object) {
                listItems += '<option value=' + object.Id + '>' + object.Name + ' </option>';
            });
            listItems += '</select>';
            $('#' + Div).append(listItems);
        },
        failure: function (msg) {
            $('#' + Div).text(msg);
        }
    });
}



//Survey Assignment Id

function GetActiveAssessgnmentDiv(_obj) {
    var Div = _obj + '_ActiveAssessgnmentDiv';
    $.ajax({
        type: "POST",
        url: "/Services/DataCollection.asmx/GetSurveyActiveListAssignment"
        , contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: function (response) {
            $('#' + Div).empty();
            var object = response.d;
            var listItems = "";
            listItems += '<select   id="' + Div.replace('Div', 'Id') + '"  class="select2_group form-control"   tabindex="-1"  placeholder="Select Assessgnment"><option value="">None</option>'; //onchange = "GetAssessgnmentIdDiv(\'' + _obj + '\', this.options[this.selectedIndex].value)"  
            $.each(object, function (index, object) {
                listItems += '<option value=' + object.Id + '>' + object.Name + ' </option>';
            });
            listItems += '</select>';
            $('#' + Div).append(listItems);
        },
        failure: function (msg) {
            $('#' + Div).text(msg);
        }
    }); 
}


//Get Survey for dropdownlist

function GetSurveyDropdownDiv(_obj) {
    var Div = _obj + '_NameDiv';
    $.ajax({
        type: "POST",
        url: "/Services/DataCollection.asmx/GetSurveyDropdownlist"
        , contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: function (response) {
            $('#' + Div).empty();
            var object = response.d;
            var listItems = "";
            listItems += '<select   id="' + Div.replace('Div', 'Id') + '" class="select2_group form-control"   tabindex="-1"  placeholder="Select Survey"><option value="">None</option>'; //onchange = "ViewSurveyReports(\'' + _obj + '\', this.options[this.selectedIndex].value)"
            //listItems += '<select   id="' + Div.replace('Div', 'Id') + '" onchange = "GetSurveyReportById(\'' + _Id + '\', this.options[this.selectedIndex].value)" class="select2_group form-control"   tabindex="-1"  placeholder="Select Survey"><option value="">None</option>';
            $.each(object, function (index, object) {
                listItems += '<option value=' + object.Id + '>' + object.Name + ' </option>';
            });
            listItems += '</select>';
            $('#' + Div).append(listItems);
        },
        failure: function (msg) {
            $('#' + Div).text(msg);
        }
    });
}

//For Survey link
function GetQuestionsActiveAssessgnmentDiv(_obj) {
    var Div = _obj + 'QuestionsActiveAssessgnmentDiv';
    $.ajax({
        type: "POST",
        url: "/Services/DataCollection.asmx/GetSurveyQuestionsActiveListAssignment"
        , contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: function (response) {
            $('#' + Div).empty();
            var object = response.d;
            var listItems = "";
            listItems += '<select   id="' + Div.replace('Div', 'Id') + '"  class="select2_group form-control"   tabindex="-1"placeholder="Select Survey Question"><option value="">None</option>'; //onchange = "GetAssessgnmentIdDiv(\'' + _obj + '\', this.options[this.selectedIndex].value)"  
            $.each(object, function (index, object) {
                listItems += '<option value=' + object.Id + '>' + object.Question + ' </option>';
            });
            listItems += '</select>';
            $('#' + Div).append(listItems);
        },
        failure: function (msg) {
            $('#' + Div).text(msg);
        }
    });
}

//For Survey link
function GetSurveylinqDiv(_obj) {
    var Div = _obj + 'linqDiv';
    $.ajax({
        type: "POST",
        url: "/Services/DataCollection.asmx/GetSurveyNameLinqView"
        , contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: function (response) {
            $('#' + Div).empty();
            var object = response.d;
            var listItems = "";
            listItems += '<select   id="' + Div.replace('Div', 'Id') + '"  class="select2_group form-control"   tabindex="-1"placeholder="Select Survey Question"><option value="">None</option>'; //onchange = "GetAssessgnmentIdDiv(\'' + _obj + '\', this.options[this.selectedIndex].value)"  
            $.each(object, function (index, object) {
                listItems += '<option value=' + object.Id + '>' + object.Name  + ' </option>';
            });
            listItems += '</select>';
            $('#' + Div).append(listItems);
        },
        failure: function (msg) {
            $('#' + Div).text(msg);
        }
    });
}
