﻿function GetSuppliersLookUp(Div, SearchText) {
    var obj = {};
    obj.SearchText = document.getElementById(SearchText).value;
    $.ajax({
        type: "POST",
        url: "/Services/DataCollection.asmx/GetSuppliersLookUp",
        data: JSON.stringify(obj),
        contentType: "application/json; charset=utf-8",
        success: function (response) {
            var Suppliers = response.d
            $('#' + Div).empty();
            $('#' + Div).append('<thead><th>Suppliers</th></thead><tbody>')
            $.each(Suppliers, function (index, Suppliers) {
                $('#' + Div).append('<tr>' + '<td value=' + Suppliers.Id + '> <div   data-toggle="dropdown"  onclick="UpdateTagValue(\'' + SearchText + '\',\'[' + Suppliers.Id + '] ' + Suppliers.Name + ' \');"   > <span style="color:#34495E;font-weight: bold;">[ ' + Suppliers.Id + ' ]</span> ' + Suppliers.Name + ' </div></td></tr>')
            });
            $('#' + Div).append('</tbody>');
        },
        failure: function (msg) {
            $('#' + Div).text(msg);
        }
    });
};
function GetCityLookUp(Div, SearchText) {
    var obj = {};
    obj.SearchText = document.getElementById(SearchText).value;
    $.ajax({
        type: "POST",
        url: "/Services/DataCollection.asmx/GetAllCity",
        data: JSON.stringify(obj),
        contentType: "application/json; charset=utf-8",
        success: function (response) {
            var Suppliers = response.d
            $('#' + Div).empty();
            $('#' + Div).append('<thead><th>Suppliers</th></thead><tbody>')
            $.each(Suppliers, function (index, Suppliers) {
                $('#' + Div).append('<tr>' + '<td value=' + Suppliers.Id + '> <div   data-toggle="dropdown"  onclick="UpdateTagValue(\'' + SearchText + '\',\'[' + Suppliers.Id + '] ' + Suppliers.Name + ' \');"   > <span style="color:#34495E;font-weight: bold;">[ ' + Suppliers.Id + ' ]</span> ' + Suppliers.Name + ' </div></td></tr>')
            });
            $('#' + Div).append('</tbody>');
        },
        failure: function (msg) {
            $('#' + Div).text(msg);
        }
    });
};
function GetDepartmentLookUp(Div, SearchText) {
    var obj = {};
    obj.SearchText = document.getElementById(SearchText).value;
    $.ajax({
        type: "POST",
        url: "/Services/DataCollection.asmx/GetAllDepartments",
        data: JSON.stringify(obj),
        contentType: "application/json; charset=utf-8",
        success: function (response) {
            var Suppliers = response.d
            $('#' + Div).empty();
            $('#' + Div).append('<thead><th>Suppliers</th></thead><tbody>')
            $.each(Suppliers, function (index, Suppliers) {
                $('#' + Div).append('<tr>' + '<td value=' + Suppliers.Id + '> <div   data-toggle="dropdown"  onclick="UpdateTagValue(\'' + SearchText + '\',\'[' + Suppliers.Id + '] ' + Suppliers.Name + ' \');"   > <span style="color:#34495E;font-weight: bold;">[ ' + Suppliers.Id + ' ]</span> ' + Suppliers.Name + ' </div></td></tr>')
            });
            $('#' + Div).append('</tbody>');
        },
        failure: function (msg) {
            $('#' + Div).text(msg);
        }
    });
};
function GetStatusLookUp(Div, SearchText) {
    var obj = {};
    obj.SearchText = document.getElementById(SearchText).value;
    $.ajax({
        type: "POST",
        url: "/Services/DataCollection.asmx/GetAllStatus",
        data: JSON.stringify(obj),
        contentType: "application/json; charset=utf-8",
        success: function (response) {
            var Suppliers = response.d
            $('#' + Div).empty();
            $('#' + Div).append('<thead><th>Suppliers</th></thead><tbody>')
            $.each(Suppliers, function (index, Suppliers) {
                $('#' + Div).append('<tr>' + '<td value=' + Suppliers.Id + '> <div   data-toggle="dropdown"  onclick="UpdateTagValue(\'' + SearchText + '\',\'[' + Suppliers.Id + '] ' + Suppliers.Name + ' \');"   > <span style="color:#34495E;font-weight: bold;">[ ' + Suppliers.Id + ' ]</span> ' + Suppliers.Name + ' </div></td></tr>')
            });
            $('#' + Div).append('</tbody>');
        },
        failure: function (msg) {
            $('#' + Div).text(msg);
        }
    });
};

function GetProvinceLookUp(Div) {
    $.ajax({

        type: "POST",
        url: "/Services/DataCollection.asmx/GetAllProvince"
        , contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: function (response) {
            $('#' + Div).empty();
            var Types = response.d;
            var listItems = "";
            listItems += '<select   id="' + Div.replace('Div', 'Id') +'"  class="select2_group form-control"  onclick="GetCityByProviceLookUp(this.options[this.selectedIndex].value)"  tabindex="-1"  placeholder="Select Vehicle LicenseTypes"><option value="0"  selected>Select</option>';
            $.each(Types, function (index, Types) {
                listItems += '<option value=' + Types.Id + '>' + Types.Name + ' </option>';
            });
            listItems += '</select>';
            $('#' + Div).append(listItems);
        },
        failure: function (msg) {
            $('#' + Div).text(msg);
        }
    });
};    
function GetCityLookUp(Div) {
    $.ajax({

        type: "POST",
        url: "/Services/DataCollection.asmx/GetAllProvinces"
        , contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: function (response) {
            $('#' + Div).empty();
            var Types = response.d;
            var listItems = "";
            listItems += '<select   id="' + Div.replace('Div', 'Id') + '"  class="select2_group form-control"   tabindex="-1"  placeholder="Select Vehicle LicenseTypes"><option value="0"  selected>Select</option>';
            $.each(Types, function (index, Types) {
                listItems += '<option value=' + Types.Id + '>' + ' [ ' + Types.code + ' ]  ' + Types.region + ' </option>';
            });
            listItems += '</select>';
            $('#' + Div).append(listItems);
        },
        failure: function (msg) {
            $('#' + Div).text(msg);
        }
    });
};  
function GetCityByProviceLookUp(ProvinceId) {
    var Div = 'Suppliers_CityDiv';
    var obj = {};
    obj.ProvinceId = ProvinceId
    $.ajax({
       
        type: "POST",
        data: JSON.stringify(obj),
        url: "/Services/DataCollection.asmx/GetAllCityByProvinceId"
        , contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: function (response) {
            $('#' + Div).empty();
            var Types = response.d;
            var listItems = "";
            listItems += '<select   id="' + Div.replace('Div', 'Id') + '"  class="select2_group form-control"   tabindex="-1"  placeholder="Select Vehicle LicenseTypes"><option value="0"  selected>Select</option>';
            $.each(Types, function (index, Types) {
                listItems += '<option value=' + Types.Id + '>' + ' ' + Types.Name + ' </option>';
            });
            listItems += '</select>';
            $('#' + Div).append(listItems);
        },
        failure: function (msg) {
            $('#' + Div).text(msg);
        }
    });
};   
function GetLookupHtml(ControlId, Type, zindex) {
    $('#' + ControlId).append(
        '<label class="control-label col-md-2 col-sm-2 col-xs-12" for="first-name">' + Type + ': </label>     ' +
        '         <div class="col-md-6 col-sm-6 col-xs-12"   style="z-index: ' + zindex + ';">     ' +
        '            <div class="input-group" id="adv-search"   style="z-index: 0;">     ' +
        '     <input type="text"  id="' + Type + 'SearchText" class="form-control" placeholder="Search for ' + Type + '" />     ' +
        '     <div class="input-group-btn">     ' +
        '         <div class="btn-group" role="group">     ' +
        '             <div class="dropdown  dropdown-lg">     ' +
        '                 <button type="button" class="btn btn-default dropdown-toggle" data-toggle="dropdown"  id="DropDown' + ControlId + '"  aria-expanded="false"><span class="caret"></span></button>     ' +
        '                 <button type="button"  data-toggle="dropdown"  data-target="#DropDown' + Type + '"  aria-expanded="false" onclick="Get' + Type + 'LookUp(\'' + Type + 'ResultsTable\',\'' + Type + 'SearchText\')" class="btn btn-primary"><span class="glyphicon glyphicon-search"  ></span></button>     ' +
        '                 <div  id="DropDown' + ControlId + '"  class="dropdown-menu dropdown-menu-right" role="menu"    style="box-shadow: 4px 4px #ccc; z-index: 999 !important;">     ' +
        '                     <form class="form-horizontal" role="form">     ' +
        '                       <div class="form-group">     ' +
        '                      <table id="' + Type + 'ResultsTable" class="table table-striped" style="width:100%;background: #fff;background-color: white;">     ' +
        '           <thead>     ' +
        '             <tr>      ' +
        '               <th>Results</th>     ' +
        '             </tr>     ' +
        '           </thead>     ' +
        '           <tbody>     ' +
        '             <tr>     ' +
        '               <td>No Results</td>     ' +
        '             </tr>      ' +
        '           </tbody>     ' +
        '         </table>     ' +
        '                       </div>       ' +
        ' </form></div></div></div></div></div></div>');

};



function GetTypeLookUp(Div) {
    $.ajax({

        type: "POST",
        url: "/Services/DataCollection.asmx/GetAllEntryType"
        , contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: function (response) {
            $('#' + Div).empty();
            var Types = response.d;
            var listItems = "";
            listItems += '<select   id="' + Div.replace('Div', 'Id') + '"  class="select2_group form-control"   tabindex="-1"  placeholder="Select Vehicle LicenseTypes"><option value="0"  selected>Select</option>';
            $.each(Types, function (index, Types) {
                listItems += '<option value=' + Types.Id + '>' + ' ' + Types.Name + ' </option>';
            });
            listItems += '</select>';
            $('#' + Div).append(listItems);
        },
        failure: function (msg) {
            $('#' + Div).text(msg);
        }
    });
};  
function GetStatusLookUp(Div) {
    $.ajax({

        type: "POST",
        url: "/Services/DataCollection.asmx/GetAllStatus"
        , contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: function (response) {
            $('#' + Div).empty();
            var Types = response.d;
            var listItems = "";
            listItems += '<select   id="' + Div.replace('Div', 'Id') + '"  class="select2_group form-control"   tabindex="-1"  placeholder="Select Vehicle LicenseTypes"><option value="0"  selected>Select</option>';
            $.each(Types, function (index, Types) {
                listItems += '<option value=' + Types.Id + '>' + ' ' + Types.Name + ' </option>';
            });
            listItems += '</select>';
            $('#' + Div).append(listItems);
        },
        failure: function (msg) {
            $('#' + Div).text(msg);
        }
    });
};  
function GetActionLookUp(Div) {
    $.ajax({

        type: "POST",
        url: "/Services/DataCollection.asmx/GetAllAction"
        , contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: function (response) {
            $('#' + Div).empty();
            var Types = response.d;
            var listItems = "";
            listItems += '<select   id="' + Div.replace('Div', 'Id') + '"  class="select2_group form-control"   tabindex="-1"  placeholder="Select Vehicle LicenseTypes"><option value="0"  selected>Select</option>';
            $.each(Types, function (index, Types) {
                listItems += '<option value=' + Types.Id + '>' + ' ' + Types.Name + ' </option>';
            });
            listItems += '</select>';
            $('#' + Div).append(listItems);
        },
        failure: function (msg) {
            $('#' + Div).text(msg);
        }
    });
};  
function GetDepartmentsLookUp(Div, SearchText) {
    var obj = {};
    obj.SearchText = document.getElementById(SearchText).value;
    $.ajax({
        type: "POST",
        url: "/Services/DataCollection.asmx/GetDepartmentsLookUp",
        data: JSON.stringify(obj),
        contentType: "application/json; charset=utf-8",
        success: function (response) {
            var Suppliers = response.d
            $('#' + Div).empty();
            $('#' + Div).append('<thead><th>Departments</th></thead><tbody>')
            $.each(Suppliers, function (index, Suppliers) {
                $('#' + Div).append('<tr>' + '<td value=' + Suppliers.Id + '> <div   data-toggle="dropdown"  onclick="UpdateTagValue(\'' + SearchText + '\',\'[' + Suppliers.Id + '] ' + Suppliers.Name + ' \');"   > <span style="color:#34495E;font-weight: bold;">[ ' + Suppliers.Id + ' ]</span> ' + Suppliers.Name + ' </div></td></tr>')
            });
            $('#' + Div).append('</tbody>');
        },
        failure: function (msg) {
            $('#' + Div).text(msg);
        }
    });
};


function UpdateTagValue(InputTagId, inputTagValue) {

    document.getElementById(InputTagId).value = inputTagValue;

};
