﻿function GetAllProvinceDiv(Div) {
    $.ajax({

        type: "POST",
        url: "/Services/DataCollection.asmx/GetAllProvince"

        , contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: function (response) {
            $('#' + Div).empty();
            var Portals = response.d;
            var listItems = "";
            listItems += '<select   id="' + Div.replace('Div', 'Id') + '"   class="select2_group form-control"  onclick="GetAllDeparmentDiv(this.options[this.selectedIndex].value)"    tabindex="-1"  placeholder="Select Vehicle Portals"><option value="">None</option>';
            $.each(Portals, function (index, Portals) {
                listItems += '<option value=' + Portals.Id + '>' + Portals.Name + ' </option>';
            });
            listItems += '</select>';
            $('#' + Div).append(listItems);
        },
        failure: function (msg) {
            $('#' + Div).text(msg);
        }
    });
}

function GetSectorLookUp(Div) {
    $.ajax({

        type: "POST",
        url: "/Services/DataCollection.asmx/GetAllSectors"

        , contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: function (response) {
            $('#' + Div).empty();
            var Portals = response.d;
            var listItems = "";
            listItems += '<select   id="' + Div.replace('Div', 'Id') + '"   class="select2_group form-control"  onclick="GetAllDeparmentDiv(this.options[this.selectedIndex].value)"    tabindex="-1"  placeholder="Select Vehicle Portals"><option value="">None</option>';
            $.each(Portals, function (index, Portals) {
                listItems += '<option value=' + Portals.Id + '>' + Portals.Name + ' </option>';
            });
            listItems += '</select>';
            $('#' + Div).append(listItems);
        },
        failure: function (msg) {
            $('#' + Div).text(msg);
        }
    });
}



function GetAllDeparmentDiv(ProvinceId) {
    var Div = 'AspNetUsers_Department';
    var obj = {};
    obj.ProvinceId = ProvinceId;  
    $.ajax({
        type: "POST",
        data: JSON.stringify(obj),
        url: "/Services/DataCollection.asmx/GetDepartmentsByProvinceId"
        , contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: function (response) {
            $('#' + Div).empty();
            var Portals = response.d;
            var listItems = "";
            listItems += '<select   id="' + Div.replace('Div', 'Id') + '"   class="select2_group form-control"   tabindex="-1"  placeholder="Select Vehicle Portals"><option value="">None</option>';
            $.each(Portals, function (index, Portals) {
                listItems += '<option value=' + Portals.Id + '>' + Portals.Name + ' </option>';
            });
            listItems += '</select>';
            $('#' + Div).append(listItems);
        },
        failure: function (msg) {
            $('#' + Div).text(msg);
        }
    });
}


function GetAllTargetGroupDiv(Div) {
    $.ajax({
        type: "POST",
        url: "/Services/DataCollection.asmx/GetAssessgnmentTypeGroup"
        , contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: function (response) {
            $('#' + Div).empty();
            var Portals = response.d;
            var listItems = "";
            listItems += '<select   id="' + Div.replace('Div', 'Id') + '"  class="select2_group form-control"   tabindex="-1"  placeholder="Select Vehicle Portals"><option value="">None</option>';
            $.each(Portals, function (index, Portals) {
                listItems += '<option value=' + Portals.Uid + '>' + Portals.Name + ' </option>';
            });
            listItems += '</select>';
            $('#' + Div).append(listItems);
        },
        failure: function (msg) {
            $('#' + Div).text(msg);
        }
    });
}





function GetAllAssessgnmentTypeDiv(Div) {


    $.ajax({
        type: "POST",
        url: "/Services/DataCollection.asmx/GeAllAssessgnmentType"
        , contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: function (response) {
            $('#' + Div).empty();
            var Portals = response.d;
            var listItems = "";
            listItems += '<select   id="' + Div.replace('Div', 'Id') + '"  class="select2_group form-control"   tabindex="-1"  placeholder="Select Vehicle Portals"><option value="">None</option>';
            $.each(Portals, function (index, Portals) {
                listItems += '<option value=' + Portals.Id + '>' + Portals.Name + ' </option>';
            });
            listItems += '</select>';
            $('#' + Div).append(listItems);
        },
        failure: function (msg) {
            $('#' + Div).text(msg);
        }
    });
}

//GetSubmissionTypeDiv

function GeAllSubmissionTypesDiv(Div) {


    $.ajax({
        type: "POST",
        url: "/Services/DataCollection.asmx/GeAllSubmissionTypes"
        , contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: function (response) {
            $('#' + Div).empty();
            var Portals = response.d;
            var listItems = "";
            listItems += '<select   id="' + Div.replace('Div', 'Id') + '"  class="select2_group form-control"   tabindex="-1"  placeholder="Select Vehicle Portals"><option value="">None</option>';
            $.each(Portals, function (index, Portals) {
                listItems += '<option value=' + Portals.Id + '>' + Portals.Name + ' </option>';
            });
            listItems += '</select>';
            $('#' + Div).append(listItems);
        },
        failure: function (msg) {
            $('#' + Div).text(msg);
        }
    });
}


function GetAllAssessor(Div) {


    $.ajax({
        type: "POST",
        url: "/Services/DataCollection.asmx/GetAllAssessor"
        , contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: function (response) {
            $('#' + Div).empty();
            var Portals = response.d;
            var listItems = "";
            listItems += '<select style="height:200px;"  id="' + Div.replace('Div', 'Id') + '"  class="select2_group form-control" multiple="multiple"   tabindex="-1"  placeholder="Select Vehicle Portals"><option value="">None</option>';
            $.each(Portals, function (index, Portals) {
                listItems += '<option value=' + Portals.Id + '>' + Portals.Name + ' '+Portals.Surname + ' </option>';
            });
            listItems += '</select>';
            $('#' + Div).append(listItems);
        },
        failure: function (msg) {
            $('#' + Div).text(msg);
        }
    });
}


function GetAllSectorExperts(Div) {
    $.ajax({
        type: "POST",
        url: "/Services/DataCollection.asmx/GetAllExperts"
        , contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: function (response) {
            $('#' + Div).empty();
            var Portals = response.d;
            var listItems = "";
            listItems += '<select   id="' + Div.replace('Div', 'Id') + '"  class="select2_group form-control"   tabindex="-1"  placeholder="Select Vehicle Portals"><option value="">None</option>';
            $.each(Portals, function (index, Portals) {
                listItems += '<option value=' + Portals.Id + '>' + Portals.Name + ' ' + Portals.Surname + ' </option>';
            });
            listItems += '</select>';
            $('#' + Div).append(listItems);
        },
        failure: function (msg) {
            $('#' + Div).text(msg);
        }
    });
}