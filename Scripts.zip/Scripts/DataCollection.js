﻿function GetAllAspNetRoles() {
    var obj = {};
    $.ajax({
        type: "POST",
        data: JSON.stringify(obj),
        url: "/Services/DataCollection.asmx/GetAllAspNetRoles",
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: function (response) {
            var AspNetRoles = response.d;
            $('#DisplayData').dataTable().fnClearTable();
            $('#DisplayData').DataTable().destroy();
            $('#DisplayData').empty();
            $('#DisplayData').append('<thead><th>view</th></thead><tbody>');
            $.each(AspNetRoles, function (index, AspNetRoles) {
                $('#DisplayData').append('<tr>' +
                    '<td style="text-align: center"><label onclick="GetAspNetRolesById(' + AspNetRoles.Id + ');"  class="fa fa-arrow-right" data-toggle="modal" data-target="#AspNetRolesModals" style="font-weight: 700;color: green;"> Edit </label> | <label style="font-weight: 700;color: red;" class="fa fa-close" onclick="DeleteAspNetRoles(' + AspNetRoles.Id + ')" >Delete</label></td>' +

                    '</tr>');
            }); $('#DisplayData').append('</tbody>');
            $('#DisplayData').append('<tfoot> <tr onclick="ClearAspNetRoles();"><td border="0" style="border:0px;text-align: center;" ><label  class="fa fa-plus" data-toggle="modal" data-target="#AspNetRolesModals"> Add New </label></td></tr></tfoot>');
            $('i').remove(".fa-refresh");
            $('#DisplayData').dataTable({
                dom: "Bfrtip", buttons: [
                    { extend: "csv", className: "btn-sm" },
                    { extend: "excel", className: "btn-sm" },
                    { extend: "pdfHtml5", className: "btn-sm" },
                    { extend: "print", className: "btn-sm" }],
                destroy: true,
                responsive: true,
                paging: true,
                searching: true
            });
        },
        failure: function (msg) {
            $('#DisplayData').text(msg);
        }
    });
};
function SaveAspNetRoles() {
    var obj = {};

    $.ajax({
        type: "POST",
        url: "/Services/DataCollection.asmx/SaveAspNetRoles",
        data: "{ _AspNetRoles:" + JSON.stringify(obj) + "}",
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: function (response) {
            var Mess = response.d;
            if (Mess.Message == 'Saved') {
                document.getElementById('AspNetRoles_Id').innerHTML = Mess.Id;
                document.getElementById('AspNetRolesStatusUpdateMessgae').innerHTML = Mess.Message;
                GetAllAspNetRoles();
            }
        },
        failure: function (msg) {
            document.getElementById('AspNetRolesStatusUpdateMessgae').innerHTML = msg;
        }
    });
}
function DeleteAspNetRoles(_Id) {
    var obj = {};
    obj._Id = _Id;
    $.ajax({
        type: "POST",
        url: "/Services/DataCollection.asmx/DeleteAspNetRoles",
        data: JSON.stringify(obj),
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: function (response) {
            GetAllAspNetRoles();
        },
        failure: function (msg) {
        }
    });
}
function ClearAspNetRoles() {
    document.getElementById('AspNetRolesStatusUpdateMessgae').innerHTML = '';

}; 
function GetAllAspNetUsers() {
    var obj = {};
    $.ajax({
        type: "POST",
        data: JSON.stringify(obj),
        url: "/Services/DataCollection.asmx/GetAllAspNetUser",
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: function (response) {
            var AspNetUsers = response.d;
            $('#DisplayData').dataTable().fnClearTable();
            $('#DisplayData').DataTable().destroy();
            $('#DisplayData').empty();
            $('#DisplayData').append('<thead><th>view</th><th>Email</th><th>Name</th><th>Surname</th><th>Phone Number</th><th>UserName</th><th>Department Name</th><th>Roles</th><th>EmailConfirmed</th><th>Approved Status</th><th>Active</th></thead><tbody>');
            $.each(AspNetUsers, function (index, AspNetUsers) {
                $('#DisplayData').append('<tr>' +
                    '<td style="text-align: center"><label onclick="GetAspNetUsersById(\'' + AspNetUsers.Id + '\');"  class="fa fa-arrow-right" data-toggle="modal" data-target="#DepartmentUsersModals" style="font-weight: 700;color: green;"> Edit </label> |<label onclick="GetAspNetUsersAproveById(\'' + AspNetUsers.Id + '\');"  class="fa fa-arrow-right" data-toggle="modal" data-target="#ApprovalRegistrationModels" style="font-weight: 700;color: blue;"> Verify </label>| <label style="font-weight: 700;color: red;" class="fa fa-close" onclick="DeleteAspNetUsers(\'' + AspNetUsers.Id + '\')" >De-Activate</label></td>' +
                    '<td>' + AspNetUsers.Email + '</td>' +
                    '<td>' + AspNetUsers.Name + '</td>' +
                    '<td>' + AspNetUsers.Surname + '</td>' +
                    '<td>' + AspNetUsers.PhoneNumber + '</td>' +
                    '<td>' + AspNetUsers.UserName + '</td>' +
                    '<td>' + AspNetUsers.DepartmentName + '</td>' +
                    '<td>' + AspNetUsers.Roles + '</td>' +
                    '<td>' + AspNetUsers.EmailConfirmed + '</td>' +
                    '<td>' + AspNetUsers.Approval_Status + '</td>' +
                    '<td>' + AspNetUsers.Active + '</td>' + 
                 
                    '</tr>');
            }); $('#DisplayData').append('</tbody>');
            $('#DisplayData').append('<tfoot> <tr onclick="ClearAspNetUsers();"><td border="0" style="border:0px;text-align: center;" ><label  class="fa fa-plus" hidden=true data-toggle="modal" data-target="#AspNetUsersModals"> Add New </label></td></tr></tfoot>');
            $('i').remove(".fa-refresh");
            $('#DisplayData').dataTable({
                dom: "Bfrtip", buttons: [
                    { extend: "csv", className: "btn-sm" },
                    { extend: "excel", className: "btn-sm" },
                    { extend: "pdfHtml5", className: "btn-sm" },
                    { extend: "print", className: "btn-sm" }],
                destroy: true,
                responsive: true,
                paging: true,
                searching: true
            });

        
        },
        failure: function (msg) {
            $('#DisplayData').text(msg);
        }
    });
};

function GetDeActivatedAspNetUsers() {
    var obj = {};
    $.ajax({
        type: "POST",
        data: JSON.stringify(obj),
        url: "/Services/DataCollection.asmx/GetDeActivatedAspNetUser",
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: function (response) {
            var AspNetUsers = response.d;
            $('#DisplayData').dataTable().fnClearTable();
            $('#DisplayData').DataTable().destroy();
            $('#DisplayData').empty();
            $('#DisplayData').append('<thead><th>view</th><th>Email</th><th>Name</th><th>Surname</th><th>Phone Number</th><th>UserName</th><th>Department Name</th><th>Roles</th><th>EmailConfirmed</th><th>Approved Status</th><th>Active</th></thead><tbody>');
            $.each(AspNetUsers, function (index, AspNetUsers) {
                $('#DisplayData').append('<tr>' +
                    '<td <label style="font-weight: 700;color: green;" class="fa fa-close" onclick="ReActivateAspNetUsers(\'' + AspNetUsers.Id + '\')" >Activate</label></td>' +
                    '<td>' + AspNetUsers.Email + '</td>' +
                    '<td>' + AspNetUsers.Name + '</td>' +
                    '<td>' + AspNetUsers.Surname + '</td>' +
                    '<td>' + AspNetUsers.PhoneNumber + '</td>' +
                    '<td>' + AspNetUsers.UserName + '</td>' +
                    '<td>' + AspNetUsers.DepartmentName + '</td>' +
                    '<td>' + AspNetUsers.Roles + '</td>' +
                    '<td>' + AspNetUsers.EmailConfirmed + '</td>' +
                    '<td>' + AspNetUsers.Approval_Status + '</td>' +
                    '<td>' + AspNetUsers.Active + '</td>' +

                    '</tr>');
            }); $('#DisplayData').append('</tbody>');
            $('#DisplayData').append('<tfoot> <tr onclick="ClearAspNetUsers();"><td border="0" style="border:0px;text-align: center;" ><label  class="fa fa-plus" hidden=true data-toggle="modal" data-target="#AspNetUsersModals"> Add New </label></td></tr></tfoot>');
            $('i').remove(".fa-refresh");
            $('#DisplayData').dataTable({
                dom: "Bfrtip", buttons: [
                    { extend: "csv", className: "btn-sm" },
                    { extend: "excel", className: "btn-sm" },
                    { extend: "pdfHtml5", className: "btn-sm" },
                    { extend: "print", className: "btn-sm" }],
                destroy: true,
                responsive: true,
                paging: true,
                searching: true
            });

        },
        failure: function (msg) {
            $('#DisplayData').text(msg);
        }
    });
};

function GetAspNetUsersById(AspNetUsersId) {

    ClearAspNetUsers();
    var obj = {};
    obj.Id = AspNetUsersId;
 
    
    $.ajax({
        type: "POST",
        url: "/Services/DataCollection.asmx/GetAspNetUsersById",
        data: JSON.stringify(obj),
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: function (response) {
            var AspNetUsers = response.d;
            try {
             /*   alert(AspNetUsers.Id);*/
                document.getElementById('AspNetUsers_Id').innerHTML = AspNetUsers.Id;
                document.getElementById('AspNetUsers_Email').value = AspNetUsers.Email;
                document.getElementById('AspNetUsers_Name').value = AspNetUsers.Name;
                document.getElementById('AspNetUsers_Surname').value = AspNetUsers.Surname;
                document.getElementById('AspNetUsers_USerRoleId').value = AspNetUsers.RoleId;
                document.getElementById('AspNetUsers_DepartmentId').value = AspNetUsers.DepartmentId;
            }
            catch (exception)  {
            }
        },
        failure: function (msg) {
            $('#Erroroutput').text(msg);
        }
    });
}

function GetContactById(ContactId) {

   
  
    var obj = {};
    obj.Id = ContactId;


    $.ajax({
        type: "POST",
        url: "/Services/DataCollection.asmx/GetContactById",
        data: JSON.stringify(obj),
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: function (response) {
            var Contacts= response.d;
            try {
                
               document.getElementById('Contact_Id').innerHTML = Contacts.ContactId;
                document.getElementById('Contact_Name').value = Contacts.Name;
                document.getElementById('Contact_Surname').value = Contacts.Surname;
                document.getElementById('Contact_Email').value = Contacts.Email;
                document.getElementById('Contact_PhoneNumber').value = Contacts.PhoneNumber;
                document.getElementById('Contact_Department').value = Contacts.Department;
                document.getElementById('Contact_Province').value = Contacts.Province;
        
            }
            catch (exception) {
            }
        },
        failure: function (msg) {
            $('#Erroroutput').text(msg);
        }
    });
}

function GetAspNetUsersAproveById(AspNetUsersId) {

    ClearAspNetUsers();
    var obj = {};
    obj.Id = AspNetUsersId;


    $.ajax({
        type: "POST",
        url: "/Services/DataCollection.asmx/GetAspNetUsersAproveById",
        data: JSON.stringify(obj),
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: function (response) {
            var AspNetUsers = response.d;
            try {

            /*    alert(AspNetUsers.Id);*/
                document.getElementById('AspNetUsers_Id').innerHTML = AspNetUsers.Id;

            }
            catch (exception) {
            }
        },
        failure: function (msg) {
            $('#Erroroutput').text(msg);
        }
    });
}

function GetAspNetUserById(AspNetUsersId) {
    ClearAspNetUsers();
    var obj = {};
    obj.Id = AspNetUsersId;


    $.ajax({
        type: "POST",
        url: "/Services/DataCollection.asmx/GetAspNetUsersById",
        data: JSON.stringify(obj),
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: function (response) {
            var AspNetUsers = response.d;
            try {

                document.getElementById('AspNetUsers_Id').innerHTML = AspNetUsers.Id;
                document.getElementById('Approval_USerDiv').value = AspNetUsers.Approval_Status;
                document.getElementById('AspNetUsers_Reason').value = AspNetUsers.Reason;
              
            }
            catch (exception) {
            }
        },
        failure: function (msg) {
            $('#Erroroutput').text(msg);
        }
    });
}
function SaveAspNetUsers() {
    var obj = {};
    obj.CId = document.getElementById('AspNetUsers_CId').value;
    obj.Id = document.getElementById('AspNetUsers_Id').value;
    obj.Email = document.getElementById('AspNetUsers_Email').value;
    obj.Name = document.getElementById('AspNetUsers_Name').value;
    obj.Surname = document.getElementById('AspNetUsers_Surname').value;
    obj.PasswordHash = document.getElementById('AspNetUsers_PasswordHash').value;
    obj.SecurityStamp = document.getElementById('AspNetUsers_SecurityStamp').value;
    obj.PhoneNumber = document.getElementById('AspNetUsers_PhoneNumber').value;
    obj.AccessFailedCount = document.getElementById('AspNetUsers_AccessFailedCount').value;
    obj.UserName = document.getElementById('AspNetUsers_UserName').value;
    obj.LockoutEndDateUtc = document.getElementById('AspNetUsers_LockoutEndDateUtc').value;
    obj.LockoutEnabled = document.getElementById('AspNetUsers_LockoutEnabled').value;
    obj.PhoneNumberConfirmed = document.getElementById('AspNetUsers_PhoneNumberConfirmed').value;
    obj.TwoFactorEnabled = document.getElementById('AspNetUsers_TwoFactorEnabled').value;
    obj.EmailConfirmed = document.getElementById('AspNetUsers_EmailConfirmed').value;
    obj.Active = document.getElementById('AspNetUsers_Active').value; 


    $.ajax({
        type: "POST",
        url: "/Services/DataCollection.asmx/SaveAspNetUsers",
        data: "{ _AspNetUsers:" + JSON.stringify(obj) + "}",
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: function (response) {
            var Mess = response.d;
            if (Mess.Message == 'Saved') {
                document.getElementById('AspNetUsers_Id').innerHTML = Mess.Id;
                document.getElementById('AspNetUsersStatusUpdateMessgae').innerHTML = Mess.Message;
                GetAllAspNetUsers();

            }

            alert('User Successfully to the SEIAS');
        },
        failure: function (msg) {
            document.getElementById('AspNetUsersStatusUpdateMessgae').innerHTML = msg;
        }
    });
}
function DeleteAspNetUsers(_Id) {
    var obj = {};
    obj._Id = _Id;   
    var x = confirm("Are you sure you want to de-activate?");
    if (x === true) {
        $.ajax({
            type: "POST",
            url: "/Services/DataCollection.asmx/DeleteAspNetUsers",
            data: JSON.stringify(obj),
            contentType: "application/json; charset=utf-8",
            dataType: "json",
            success: function (response) {
                GetAllAspNetUsers();
            },
            failure: function (msg) {
            }
        });
    }

}

function ReActivateAspNetUsers(_Id) {
    var obj = {};
    obj._Id = _Id;
    var x = confirm("Are you sure you want to re-activate the user?");
    if (x === true) {
        $.ajax({
            type: "POST",
            url: "/Services/DataCollection.asmx/ReActivateAspNetUsers",
            data: JSON.stringify(obj),
            contentType: "application/json; charset=utf-8",
            dataType: "json",
            success: function (response) {
                GetDeActivatedAspNetUsers();
            },
            failure: function (msg) {
            }
        });
    }

}

function ClearAspNetUsers() {
    document.getElementById('AspNetUsersStatusUpdateMessgae').innerHTML = '';
    document.getElementById('AspNetUsers_Id').value = '';
    document.getElementById('AspNetUsers_Email').value = '';
    document.getElementById('AspNetUsers_Name').value = '';
    document.getElementById('AspNetUsers_Surname').value = '';


}; 
function GetAllAspNetRoles() {
    var obj = {};
    $.ajax({
        type: "POST",
        data: JSON.stringify(obj),
        url: "/Services/DataCollection.asmx/GetAllAspNetRole",
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: function (response) {
            var AspNetRoles = response.d;
            $('#DisplayData').dataTable().fnClearTable();
            $('#DisplayData').DataTable().destroy();
            $('#DisplayData').empty();
            $('#DisplayData').append('<thead><th>view</th><th>Name</th></thead><tbody>');
            $.each(AspNetRoles, function (index, AspNetRoles) {
                $('#DisplayData').append('<tr>' +
                    '<td style="text-align: center"><label onclick="GetAspNetRolesById(' + AspNetRoles.Id + ');"  class="fa fa-arrow-right" data-toggle="modal" data-target="#AspNetRolesModals" style="font-weight: 700;color: green;"> Edit </label></td>' +
                    '<td>' + AspNetRoles.Name + '</td>' +
                    '</tr>');
            }); $('#DisplayData').append('</tbody>');
            $('#DisplayData').append('<tfoot> <tr onclick="ClearAspNetRoles();"><td border="0" style="border:0px;text-align: center;" ><label  class="fa fa-plus" hidden=true data-toggle="modal" data-target="#AspNetRolesModals"> Add New </label></td></tr></tfoot>');
            $('i').remove(".fa-refresh");
            $('#DisplayData').dataTable({
                dom: "Bfrtip", buttons: [
                    { extend: "csv", className: "btn-sm" },
                    { extend: "excel", className: "btn-sm" },
                    { extend: "pdfHtml5", className: "btn-sm" },
                    { extend: "print", className: "btn-sm" }],
                destroy: true,
                responsive: true,
                paging: true,
                searching: true
            });
        },
        failure: function (msg) {
            $('#DisplayData').text(msg);
        }
    });
};
function GetAspNetRolesById(AspNetRolesId) {
    ClearAspNetRoles();
    var obj = {};
    obj._Id = AspNetRolesId;


    $.ajax({
        type: "POST",
        url: "/Services/DataCollection.asmx/GetAspNetRolesById",
        data: JSON.stringify(obj),
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: function (response) {
            var AspNetRoles = response.d;
            try {
                document.getElementById('AspNetRoles_Id').value = AspNetRoles.Id;
                document.getElementById('AspNetRoles_Name').value = AspNetRoles.Name;

            }
            catch (exception)  {
            }
        },
        failure: function (msg) {
            $('#Erroroutput').text(msg);
        }
    });
}
function SaveAspNetRoles() {
    var obj = {};
    obj.Id = document.getElementById('AspNetRoles_Id').value;
    obj.Name = document.getElementById('AspNetRoles_Name').value;

    $.ajax({
        type: "POST",
        url: "/Services/DataCollection.asmx/SaveAspNetRoles",
        data: "{ _AspNetRoles:" + JSON.stringify(obj) + "}",
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: function (response) {
            var Mess = response.d;
            if (Mess.Message == 'Saved') {
                document.getElementById('AspNetRoles_Id').innerHTML = Mess.Id;
                document.getElementById('AspNetRolesStatusUpdateMessgae').innerHTML = Mess.Message;
                GetAllAspNetRoles();
            }
        },
        failure: function (msg) {
            document.getElementById('AspNetRolesStatusUpdateMessgae').innerHTML = msg;
        }
    });
}
function DeleteAspNetRoles(_Id) {
    var obj = {};
    obj._Id = _Id;
    $.ajax({
        type: "POST",
        url: "/Services/DataCollection.asmx/DeleteAspNetRoles",
        data: JSON.stringify(obj),
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: function (response) {
            GetAllAspNetRoles();
        },
        failure: function (msg) {
        }
    });
}
function ClearAspNetRoles() {
    document.getElementById('AspNetRolesStatusUpdateMessgae').innerHTML = '';
    document.getElementById('AspNetRoles_Id').value = '';
    document.getElementById('AspNetRoles_Name').value = '';

}; 

//Contacts
function GetAllContactsView() {

    var obj = {};
    $.ajax({
        type: "POST",
        data: JSON.stringify(obj),
        url: "/Services/DataCollection.asmx/GetAllContactsView",
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: function (response) {
            var ContactsView = response.d;

            $('#DisplayData').dataTable().fnClearTable();
            $('#DisplayData').DataTable().destroy();
            $('#DisplayData').empty();
            $('#DisplayData').append('<thead><td style="width: 873pt; color: yellow; font-size: 20pt; font-family: \'Arial Black\', sans-serif; text-align: center; vertical-align: middle; background: rgb(117, 113, 113); padding-top: 1px; padding-right: 1px; padding-left: 1px; font-weight: 400; font-style: normal; border: none; white-space: nowrap;" colspan="5">SEIAS Internal Contact List&nbsp;</td></thead>');
            $('#DisplayData').append('<thead><th>Action</th><th>Name</th><th>Surname</th><th>Province</th><th>Departments</th></thead><tbody>');
            $.each(ContactsView, function (index, ContactsView) {
                $('#DisplayData').append('<tr>' +
                    '<td style="text-align: center"><label onclick="GetContactById(\'' + ContactsView.ContactId +'\');"  class="fa fa-arrow-right" data-toggle="modal" data-target="#ContactsEdit" style="font-weight: 700;color: green;"> Edit </label> </td>' +
                     //'<td>' + ContactsView.ContactId + '</td>' +
                    '<td>' + ContactsView.Name + '</td>' +
                    '<td>' + ContactsView.Surname + '</td>' +
                    '<td>' + ContactsView.Province + '</td>' +
                    '<td>' + ContactsView.Department + '</td>' +
                    

                    '</tr>');
            }); $('#DisplayData').append('</tbody>');
            $('#DisplayData').append('<tfoot> <tr onclick="ClearDepartmentsView();"><td border="0" style="border:0px;text-align: center;" ><label  class="fa fa-plus" hidden=true data-toggle="modal" data-target="#ContactsViewModals"> Add New </label></td></tr></tfoot>');
            $('i').remove(".fa-refresh");
        },
        failure: function (msg) {
            $('#DisplayData').text(msg);
        }
    });
};

//external users
function GetAllContacts() {


    var obj = {};
    $.ajax({
        type: "POST",
        data: JSON.stringify(obj),
        url: "/Services/DataCollection.asmx/GetAllContactsView",
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: function (response) {
            var ContactsView = response.d;

            $('#DisplayData').dataTable().fnClearTable();
            $('#DisplayData').DataTable().destroy();
            $('#DisplayData').empty();
            $('#DisplayData').append('<thead><td style="width: 873pt; color: yellow; font-size: 20pt; font-family: \'Arial Black\', sans-serif; text-align: center; vertical-align: middle; background: rgb(117, 113, 113); padding-top: 1px; padding-right: 1px; padding-left: 1px; font-weight: 400; font-style: normal; border: none; white-space: nowrap;" colspan="4">SEIAS Internal Contact List&nbsp;</td></thead>');
            $('#DisplayData').append('<thead><th>Name</th><th>Surname</th><th>Province</th><th>Departments</th></thead><tbody>');
            $.each(ContactsView, function (index, ContactsView) {
                $('#DisplayData').append('<tr>' +
                  
                    //'<td>' + ContactsView.ContactId + '</td>' +
                    '<td>' + ContactsView.Name + '</td>' +
                    '<td>' + ContactsView.Surname + '</td>' +
                    '<td>' + ContactsView.Province + '</td>' +
                    '<td>' + ContactsView.Department + '</td>' +
                    

                    '</tr>');
            }); $('#DisplayData').append('</tbody>');
            $('#DisplayData').append('<tfoot> <tr onclick="ClearDepartmentsView();"><td border="0" style="border:0px;text-align: center;" ><label  class="fa fa-plus" hidden=true data-toggle="modal" data-target="#ContactsViewModals"> Add New </label></td></tr></tfoot>');
            $('i').remove(".fa-refresh");
        },
        failure: function (msg) {
            $('#DisplayData').text(msg);
        }
    });
};

function GetAllDepartmentsView() {
    var obj = {};
    $.ajax({
        type: "POST",
        data: JSON.stringify(obj),
        url: "/Services/DataCollection.asmx/GetAllDepartmentsView",
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: function (response) {
            var DepartmentsView = response.d;
            $('#DisplayData').dataTable().fnClearTable();
            $('#DisplayData').DataTable().destroy();
            $('#DisplayData').empty();
            $('#DisplayData').append('<thead><th>view</th><th>Province</th><th>Sectors</th><th>Department</th><th>Total Users</th></thead><tbody>');
            $.each(DepartmentsView, function (index, DepartmentsView) {
                $('#DisplayData').append('<tr>' +
                    '<td style="text-align: center"><label onclick="GetDepartmentsViewById(' + DepartmentsView.Id + ');"  class="fa fa-arrow-right" data-toggle="modal" data-target="#DepartmentsViewModals" style="font-weight: 700;color: green;"> Edit </label> </td>' +
             
                    '<td>' + DepartmentsView.Province + '</td>' +
                    '<td>' + DepartmentsView.Sectors + '</td>' +
                    '<td>' + DepartmentsView.Name + '</td>' +
                    '<td>' + DepartmentsView.User + '</td>' +

                    '</tr>');
            }); $('#DisplayData').append('</tbody>');
            $('#DisplayData').append('<tfoot> <tr onclick="ClearDepartmentsView();"><td border="0" style="border:0px;text-align: center;" ><label  class="fa fa-plus" hidden=true data-toggle="modal" data-target="#DepartmentsViewModals"> Add New </label></td></tr></tfoot>');
            $('i').remove(".fa-refresh");
            $('#DisplayData').dataTable({
                dom: "Bfrtip", buttons: [
                    { extend: "csv", className: "btn-sm" },
                    { extend: "excel", className: "btn-sm" },
                    { extend: "pdfHtml5", className: "btn-sm" },
                    { extend: "print", className: "btn-sm" }],
                destroy: true,
                responsive: true,
                paging: true,
                searching: true
            });
        },
        failure: function (msg) {
            $('#DisplayData').text(msg);
        }
    });
};
function GetDepartmentsViewById(DepartmentsViewId) {
 /*   ClearDepartmentsView();*/
    var obj = {};
    obj._Id = DepartmentsViewId;


    $.ajax({
        type: "POST",
        url: "/Services/DataCollection.asmx/GetDepartmentsViewById",
        data: JSON.stringify(obj),
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: function (response) {
            var DepartmentsView = response.d;

       
            try {
                document.getElementById('DepartmentsView_SectorId').value = DepartmentsView.SectorId;
                document.getElementById('DepartmentsView_Id').innerHTML = DepartmentsView.Id;
                document.getElementById('DepartmentsView_ProvinceId').value = DepartmentsView.ProvinceId;
                document.getElementById('DepartmentsView_Province').value = DepartmentsView.Province;
                document.getElementById('DepartmentsView_Sectors').value = DepartmentsView.Sectors;
                document.getElementById('DepartmentsView_Name').value = DepartmentsView.Name;
                document.getElementById('DepartmentsView_User').value = DepartmentsView.User;

            }
            catch (exception) {
            }
        },
        failure: function (msg) {
            $('#Erroroutput').text(msg);
        }
    });
}

//save contacts
function SaveContactUsers() {
    var obj = {};

    alert("Saved Successfully");
    obj.Name = document.getElementById('Contact_Name').value;
    obj.ContactId = document.getElementById('Contact_Id').innerHTML;
    obj.Surname = document.getElementById('Contact_Surname').value;
    obj.Email = document.getElementById('Contact_Email').value;
    obj.PhoneNumber = document.getElementById('Contact_PhoneNumber').value;
    obj.Department = document.getElementById('Contact_Department').value;
    obj.Province = document.getElementById('Contact_Province').value;

    

    $.ajax({
        type: "POST",
        url: "/Services/DataCollection.asmx/SaveContact",
        data: "{ _ContactView:" + JSON.stringify(obj) + "}",
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: function (response) {
            var Mess = response.d;
            if (Mess.Message == 'Saved') {
                document.getElementById('Contact_Id').innerHTML = Mess.Id;
                document.getElementById('ContactStatusUpdateMessgae').innerHTML = Mess.Message;
                GetAllContactsView();
            }
        },
        failure: function (msg) {
            document.getElementById('ContactStatusUpdateMessgae').innerHTML = msg;
        }
    });
}

function SaveDepartmentsView() {
    var obj = {};
    obj.SectorId = document.getElementById('DepartmentsView_SectorId').value;
    obj.Id = document.getElementById('DepartmentsView_Id').innerHTML;
    obj.ProvinceId = document.getElementById('DepartmentsView_ProvinceId').value;
    obj.Province = document.getElementById('DepartmentsView_Province').value;
    obj.Sectors = document.getElementById('DepartmentsView_Sectors').value;
    obj.Name = document.getElementById('DepartmentsView_Name').value;
    obj.User = document.getElementById('DepartmentsView_User').value;

    $.ajax({
        type: "POST",
        url: "/Services/DataCollection.asmx/SaveDepartmentsView",
        data: "{ _DepartmentsView:" + JSON.stringify(obj) + "}",
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: function (response) {
            var Mess = response.d;
            if (Mess.Message == 'Saved') {
                document.getElementById('DepartmentsView_Id').innerHTML = Mess.Id;
                document.getElementById('DepartmentsViewStatusUpdateMessgae').innerHTML = Mess.Message;
                GetAllDepartmentsView();
            }
        },
        failure: function (msg) {
            document.getElementById('DepartmentsViewStatusUpdateMessgae').innerHTML = msg;
        }
    });
}
function DeleteDepartmentsView(_Id) {
    var obj = {};
    obj._Id = _Id;
    $.ajax({
        type: "POST",
        url: "/Services/DataCollection.asmx/DeleteDepartmentsView",
        data: JSON.stringify(obj),
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: function (response) {
            GetAllDepartmentsView();
        },
        failure: function (msg) {
        }
    });
}

function ClearDepartmentsView() {
    document.getElementById('DepartmentsViewStatusUpdateMessgae').innerHTML = '';
    document.getElementById('DepartmentsView_SectorId').value = '';
    document.getElementById('DepartmentsView_Id').innerHTML = '0';
    document.getElementById('DepartmentsView_ProvinceId').value = '';
    document.getElementById('DepartmentsView_Province').value = '';
    document.getElementById('DepartmentsView_Sectors').value = '';
    document.getElementById('DepartmentsView_Name').value = '';
    document.getElementById('DepartmentsView_User').value = '';

}; 



function GetAllReportStatitics() {
    var obj = {};
    $.ajax({
        type: "POST",
        data: JSON.stringify(obj),
        url: "/Services/DataCollection.asmx/GetAllReportStatitics",
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: function (response) {
            var ReportStatitics = response.d;
            $('#DisplayData').dataTable().fnClearTable();
            $('#DisplayData').DataTable().destroy();
            $('#DisplayData').empty();
            $('#DisplayData').append('<thead><th>Submission Type</th><th>New Submissions</th><th>ReSubmitted</th><th>Total</th><th>FeedBack</th><th>SignOff</th><th>Pending</th><th>Created date</th> <th>Proposal Name</th><th>Department</th> <th>Status</th> <th>Assessment Type</th>  </thead><tbody>');
            $.each(ReportStatitics, function (index, ReportStatitics) {
                $('#DisplayData').append('<tr>' +

                    '<td>' + ReportStatitics.Amendment + '</td>' +
                    '<td>' + ReportStatitics.NewSubmissions + '</td>' +
                    '<td>' + ReportStatitics.ReSubmitted + '</td>' +
                    '<td>' + ReportStatitics.Total + '</td>' +
                    '<td>' + ReportStatitics.FeedBack + '</td>' +
                    '<td>' + ReportStatitics.SignOff + '</td>' +
                    '<td>' + ReportStatitics.Pending + '</td>' +
                    '<td>' + ReportStatitics.Created + '</td>' +
                    '<td>' + ReportStatitics.proposalName + '</td>' +
                    '<td>' + ReportStatitics.Department + '</td>' +
                    '<td>' + ReportStatitics.Status + '</td>' +
                    '<td>' + ReportStatitics.AssessgnmentTypes + '</td>' +
                 

   

                    '</tr>'
                );
            }); $('#DisplayData').append('</tbody>');
            //$('#DisplayData').append('<tfoot> <tr onclick="ClearReportStatitics();"><td border="0" style="border:0px;text-align: center;" ><label  class="fa fa-plus" data-toggle="modal" data-target="#ReportStatiticsModals"> Total </label></td><span id="val"></span></tr> </tfoot>');
            $('#DisplayData').append('<tfoot>< tr ><td id="col1_total"><b>Total</b></td><td id="col2_total"></td><td id="col3_total"></td><td id="col4_total"></td><td id="col5_total"></td><td id="col6_total"></td><td id="col7_total"></td><td id="col8_total"></td><td id="col9_total"></td><td id="col10_total"></td><td id="col11_total"></td><td id="col12_total"></td></tr ></tfoot > ');
            $('i').remove(".fa-refresh");
            $('#DisplayData').dataTable({
                dom: "Bfrtip", buttons: [
                    { extend: "csv", className: "btn-sm" },
                    { extend: "excel", className: "btn-sm" },
                    { extend: "pdfHtml5", className: "btn-sm" },
                    { extend: "print", className: "btn-sm" }],
                destroy: true,
                responsive: true,
                paging: true,
                searching: true,
                footerCallback: function (row, data, start, end, display) {
                    var api = this.api(), data;

                    // Remove the formatting to get integer data for summation
                    var intVal = function (i) {
                        return typeof i === 'string' ?
                            i.replace(/[\$,]/g, '') * 1 :
                            typeof i === 'number' ?
                                i : 0;
                    };

                    // Total over all pages
                    total2 = api
                        .column(1)
                        .data()
                        .reduce(function (a, b) {
                            return intVal(a) + intVal(b);
                        }, 0);
                    total3 = api
                        .column(2)
                        .data()
                        .reduce(function (a, b) {
                            return intVal(a) + intVal(b);
                        }, 0);
                    total4 = api
                        .column(3)
                        .data()
                        .reduce(function (a, b) {
                            return intVal(a) + intVal(b);
                        }, 0);
                    total5 = api
                        .column(4)
                        .data()
                        .reduce(function (a, b) {
                            return intVal(a) + intVal(b);
                        }, 0);
                    total6 = api
                        .column(5)
                        .data()
                        .reduce(function (a, b) {
                            return intVal(a) + intVal(b);
                        }, 0);
                    total7 = api
                        .column(6)
                        .data()
                        .reduce(function (a, b) {
                            return intVal(a) + intVal(b);
                        }, 0);
                    // Update footer
;
                    $("#col2_total").html(total2);
                    $("#col3_total").html(total3);
                    $("#col4_total").html(total4);
                    $("#col5_total").html(total5);
                    $("#col6_total").html(total6);
                    $("#col7_total").html(total7);


     

                }
            });
        },
        failure: function (msg) {
            $('#DisplayData').text(msg);
        }
    });
};
function GetAllAssessgnment() {
    var obj = {};
    $.ajax({
        type: "POST",
        data: JSON.stringify(obj),
        url: "/Services/DataCollection.asmx/GetAllAssessgnment",
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: function (response) {
            var Assessgnment = response.d;
            $('#DisplayData').dataTable().fnClearTable();
            $('#DisplayData').DataTable().destroy();
            $('#DisplayData').empty();
            $('#DisplayData').append('<thead><th>view</th></thead><tbody>');
            $.each(Assessgnment, function (index, Assessgnment) {
                $('#DisplayData').append('<tr>' +
                    '<td style="text-align: center"><label onclick="GetAssessgnmentById(' + Assessgnment.Id + ');"  class="fa fa-arrow-right" data-toggle="modal" data-target="#AssessgnmentModals" style="font-weight: 700;color: green;"> Edit </label> | <label style="font-weight: 700;color: red;" class="fa fa-close" onclick="DeleteAssessgnment(' + Assessgnment.Id + ')" >Delete</label></td>' +

                    '</tr>');
            }); $('#DisplayData').append('</tbody>');
            $('#DisplayData').append('<tfoot> <tr onclick="ClearAssessgnment();"><td border="0" style="border:0px;text-align: center;" ><label  class="fa fa-plus" data-toggle="modal" data-target="#AssessgnmentModals"> Add New </label></td></tr></tfoot>');
            $('i').remove(".fa-refresh");
            $('#DisplayData').dataTable({
                dom: "Bfrtip", buttons: [
                    { extend: "csv", className: "btn-sm" },
                    { extend: "excel", className: "btn-sm" },
                    { extend: "pdfHtml5", className: "btn-sm" },
                    { extend: "print", className: "btn-sm" }],
                destroy: true,
                responsive: true,
                paging: true,
                searching: true
            });
        },
        failure: function (msg) {
            $('#DisplayData').text(msg);
        }
    });
};
function GetCreateAssessgnment(Name, AssessmentType, SubmissionType, AssessmentVersion ) {



    var obj = {};
    obj.Name = Name;
    obj.AssessmentType = AssessmentType; 
    obj.SubmissionType = SubmissionType; 
    obj.AssessmentVersion = AssessmentVersion; 

    if (AssessmentType != "" && SubmissionType != "" && Name != "" && AssessmentVersion !="") {
        $("#create").attr("disabled", true);
        $.ajax({
            type: "POST",
            url: "/Services/DataCollection.asmx/CreateAssessgnment",
            data: JSON.stringify(obj),
            contentType: "application/json; charset=utf-8",
            dataType: "json",
            success: function (response) {
                var Message = response.d;
                try {
                    if (AssessmentType == 1) {
                        window.location.replace('/Assessment/Initial/' + Message.Id);
                    }
                    else if (AssessmentType == 2) {
                        window.location.replace('/Assessment/Final/' + Message.Id);
                    } else if (AssessmentType == 821) {
                        window.location.replace('/Assessment/Significant/' + Message.Id);
                    } else {
                        window.location.replace('/Assessment/Significant/' + Message.Id);
                    }
                }
                catch (exception) {
                }
                //$("#create").attr("disabled", false);
            },
            failure: function (msg) {
                $("#create").attr("disabled", false);
                $('#Erroroutput').text(msg);
            }
        });
    }

   

}

function GetSaveAssementPrioty(AssessgnmentId, PriotyId, PriotyDescription) {

    var obj = {};
    obj.AssessgnmentId = AssessgnmentId;
    obj.PriotyId = PriotyId;
    obj.PriotyDescription = PriotyDescription;

    $.ajax({
        type: "POST",
        url: "/Services/DataCollection.asmx/SaveAssessgnmentPrioty",
        data: JSON.stringify(obj),
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: function (response) {
            var Message = response.d;
            try {
                if (AssessmentType == 1) {
                    window.location.replace("/Assessment/Initial/" + Message.Id);
                }
                else if (AssessmentType == 2) {
                    window.location.replace("/Assessment/Final/" + Message.Id);
                } else if (AssessmentType == 821) {
                    window.location.replace('/Assessment/Significant/' + Message.Id);
                }
            }
            catch (exception) {
            }
        },
        failure: function (msg) {
            $('#Erroroutput').text(msg);
        }
    });
}


function SaveDepartmentUsers() {

    var obj = {};
    obj.UsersId = document.getElementById('AspNetUsers_Id').innerHTML;
    obj.UserRoleId = document.getElementById("AspNetUsers_USerRoleId").value;
    obj.Email = document.getElementById("AspNetUsers_Email").value;
    obj.Name = document.getElementById("AspNetUsers_Name").value;
    obj.Surname = document.getElementById("AspNetUsers_Surname").value;
    obj.DepartmentId = document.getElementById("AspNetUsers_DepartmentId").value;
    
    $.ajax({
        type: "POST",
        url: "/Services/DataCollection.asmx/SaveUsersRoles",
        data: JSON.stringify(obj),
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: function (response) {
            var Message = response.d;
            try {

                alert('User updated');
                GetAllAspNetUsers();
               $('#DepartmentUsersModals').modal('hide');
                

            }
            catch (exception) {
            }
        },
        failure: function (msg) {
            $('#Erroroutput').text(msg);
        }
    });
}

function SaveDepartmentUserApproval() {

    var obj = {};

    alert("VHGHFGHFHGF");
    const formData = new FormData();
    obj.UserId = document.getElementById('AspNetUsers_Id').innerHTML;
    obj.UserApprovalId = document.getElementById("Approval_USerDiv").value;
    obj.UserApprovalReason = document.getElementById("AspNetUsers_Reason").value;

    formData.append('UserId', $('#AspNetUsers_Id').val());
    formData.append('UserApprovalId', $('#Approval_USerDiv').val());
    formData.append('UserApprovalReason', $('#AspNetUsers_Reason').val());
    alert(formData);
    //alert(obj.UserApprovalsId);
    //alert(obj.UserApprovalReason);

    $.ajax({
        type: "POST",
        data: "{approvalObject:" + JSON.stringify(obj) + "}",
        url: "/Services/DataCollection.asmx/SaveUsersApprovals",
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: function (response) {
            var Message = response.d;
            try {

                alert('User Updated');
             
                $('#ApprovalRegistration').modal('hide');

                GetAllAspNetUsers();
            }
            catch (exception) {
            }
        },
        failure: function (msg) {
            $('#Erroroutput').text(msg);
        }
    });
}
function SaveAssessgnment() {
    var obj = {};

    $.ajax({
        type: "POST",
        url: "/Services/DataCollection.asmx/SaveAssessgnment",
        data: "{ _Assessgnment:" + JSON.stringify(obj) + "}",
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: function (response) {
            var Mess = response.d;
            if (Mess.Message == 'Saved') {
                document.getElementById('Assessgnment_Id').innerHTML = Mess.Id;
                document.getElementById('AssessgnmentStatusUpdateMessgae').innerHTML = Mess.Message;
                GetAllAssessgnment();
            }
        },
        failure: function (msg) {
            document.getElementById('AssessgnmentStatusUpdateMessgae').innerHTML = msg;
        }
    });
}
function DeleteAssessgnment(_Id) {
    var obj = {};
    obj._Id = _Id;
    $.ajax({
        type: "POST",
        url: "/Services/DataCollection.asmx/DeleteAssessgnment",
        data: JSON.stringify(obj),
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: function (response) {
            GetAllAssessgnment();
        },
        failure: function (msg) {
        }
    });
}
function ClearAssessgnment() {
    document.getElementById('AssessgnmentStatusUpdateMessgae').innerHTML = '';

}; 

// Get Actual Assessment
function GetAllAssessmentById(_Id) {
    var obj = {};
    obj._Id = _Id;


    $.ajax({
        type: "POST",
        data: JSON.stringify(obj),
        url: "/Services/DataCollection.asmx/GetAssessgnmentById",
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: function (response) {
            var AssessmentAnswers = response.d;

            var Assment = AssessmentAnswers.Assment;
            var Answers = AssessmentAnswers.Answers;
            $('.AssementTitleId').html(Assment.Name);
            //document.getElementById('Purpose').innerHTML = Answers[0].Content;
            //tinymce.init({ selector: 'Purpose' });
            //tinymce.activeEditor.setContent(Answers[0].Content);
            //tinyMCE.get('Purpose').setContent(Answers[0].Content);
            
           //var Assment = AssessmentAnswers.Assment;
           // document.getElementById('AssementTitlesId').innerHTML = Assment.Name;
       
         
            if (Assment.StatusId == 1 || Assment.StatusId == 2) {

                $("td[contenteditable='true']").each(function (index, elem) {
                    elem.contenteditable = false;
                });
                if (Assment.Allocated != 'null') {
                    $('.AddCommentDiv').show();
                    $('.AddCommentLabel').show();
                }
                else {
                    $('.AddCommentDiv').hide();
                    $('.AddCommentLabel').hide();
                }
                $('#Allocate').hide();
                $('#FirstApproved').hide();
                $('#SecondApproved').hide();
                $('#PriorityTypeDiv').hide();

                if (Assment.Allocated != null) {
                    $('.AddCommentDiv').show();
                    $('.AddCommentLabel').show();
                }


            }
            else if (Assment.StatusId == 4) {
                $('#FirstApproved').show();
                $('#SecondApproved').hide();
                $('#Assign').show();
                $('#DepartmentSubmit').hide();
                if (Assment.Allocated != null) {
                    $('#AllocateDiv').hide();
                }
                else {
                    $('#AllocateDiv').show();
                }
            }
            else if (Assment.StatusId == 5) {

                $('#FirstApproved').hide();
                $('#SecondApproved').show();
                $('#DepartmentSubmit').hide();
            }

            else if (Assment.StatusId == 7) {
                $('#FirstApproved').hide();
                $('#SecondApproved').hide();
                $('#DepartmentSubmit').hide();
            }
            //else
            //{
            //    $('#FirstApproved').hide();
            //    $('#SecondApproved').hide();
            //    $('#DepartmentSubmit').hide();
            //}
            //$.each(Answers, function (index, _Answers) {

            //    if (_Answers.TypeId == 2) {
            //        $('#Q_' + _Answers.QuestionId + '_' + _Answers.SubStatementId + '_Div').empty();
            //        $('#C_' + _Answers.QuestionId + '_' + _Answers.SubStatementId + '_Div').empty();
            //        $('#Q_' + _Answers.QuestionId + '_' + _Answers.SubStatementId + '_Div').append(_Answers.Content);
            //    }
            //    else {

            //        $('#Q_' + _Answers.QuestionId + '_' + _Answers.SubStatementId).val(_Answers.Content);
            //    }
            //});

            //GetCommentByAssessmentsId(_Id);
        },
        failure: function (msg) {
            $('#DisplayData').text(msg);
        }
    });



};
function GetCommentByAssessmentsId(_Id) {
    var obj = {};
    obj._Id = _Id;
    $.ajax({
        type: "POST",
        data: JSON.stringify(obj),
        url: "/Services/DataCollection.asmx/GetCommentByAssessmentsId",
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: function (response) {
            var _Answers = response.d;
            $.each(_Answers, function (index, _Answers) {
                $('#C_' + _Answers.QuestionId + '_' + _Answers.SubStatementId + '_Div').append('<div  Class="' + _Answers.Roles + '" ><p contenteditable="true">' + _Answers.Content + '<br/><span  style""color:#1B3440"> By :' + _Answers.Creator + '  Date : ' + _Answers.ShortDate + '</span> </p></div>');
            });
        },
        failure: function (msg) {
            $('#DisplayData').text(msg);
        }
    });
};



function GetAllAssessgnmentByUser() {
    var obj = {};
 
    $.ajax({
        type: "POST",
        data: JSON.stringify(obj),
        url: "/Services/DataCollection.asmx/GetAllAssessgnmentByUser",
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: function (response) {
            var AssessgnmentView = response.d;
            $('#AssessgnmentByUser').append('<thead><th>view</th><th>AssessmentType</th><th>SubmissionType</th><th>Name</th><th>CreatedBy</th><th>Departments</th><th>CreatedDate</th><th>Status</th><th>Allocated</th></thead><tbody>');

            //$('#AssessgnmentByUser').dataTable().fnClearTable();
            //$('#AssessgnmentByUser').DataTable().destroy();
            //$('#AssessgnmentByUser').empty();
            $.each(AssessgnmentView, function (index, AssessgnmentView) {
                var Edit = ""; 
                if (AssessgnmentView.StatusId < 3 )
                {   
                    Edit = "Edit";
                    $('#AssessgnmentByUser').append('<tr>' +
                        '<td style="text-align: center;"><a href="/Assessment/' + AssessgnmentView.AssessmentType + '/' + AssessgnmentView.Id + '"  class="fa fa-arrow-right" style="font-weight: 700;color: green;">' + Edit + '</a> </td>' +
                        '<td>' + AssessgnmentView.AssessmentType + '</td>' +
                        '<td>' + AssessgnmentView.SubmissionType + '</td>' +
                        '<td>' + AssessgnmentView.Name + '</td>' +
                        '<td>' + AssessgnmentView.CreatedBy + '</td>' +
                        '<td>' + AssessgnmentView.Department + '</td>' +
                        '<td>' + AssessgnmentView.ShortDate + '</td>' +
                        '<td>' + AssessgnmentView.Status + '</td>' +
                        '<td>' + AssessgnmentView.Allocated + '</td>' +
                        '</tr>');
                }
                else if (AssessgnmentView.StatusId == 3) {
                    Edit = "Survey";
                    $('#AssessgnmentByUser').append('<tr>' +
                        //'<td style="text-align: center;"><a class="fa fa-arrow-right" onclick="SetSurveyAssessmentId(' + AssessgnmentView.Id + ')"  data-toggle="modal" data-target="#Surveylinq" style="font-weight: 700;color: green;">' + Edit + '</a> </td>' +                       
                        '<td>' + "Submitted" + '</td>' +
                        '<td>' + AssessgnmentView.AssessmentType + '</td>' +
                        '<td>' + AssessgnmentView.SubmissionType + '</td>' +
                        '<td>' + AssessgnmentView.Name + '</td>' +
                        '<td>' + AssessgnmentView.CreatedBy + '</td>' +
                        '<td>' + AssessgnmentView.Department + '</td>' +
                        '<td>' + AssessgnmentView.ShortDate + '</td>' +
                        '<td>' + AssessgnmentView.Status + '</td>' +
                        '<td>' + AssessgnmentView.Allocated + '</td>' +
                        '</tr>');
                }
                else if (AssessgnmentView.StatusId == 7 || AssessgnmentView.StatusId == 8) {
                    Edit = "Published";
                    $('#AssessgnmentByUser').append('<tr>' +
                        '<td style="text-align: center;"><a target="_blank" href="Documents/' + AssessgnmentView.Id+ '-final.pdf"  class="fa fa-arrow-right" style="font-weight: 700;color: green;">View Report</a> </td>' +
                        '<td>' + AssessgnmentView.AssessmentType + '</td>' +
                        '<td>' + AssessgnmentView.SubmissionType + '</td>' +
                        '<td>' + AssessgnmentView.Name + '</td>' +
                        '<td>' + AssessgnmentView.CreatedBy + '</td>' +
                        '<td>' + AssessgnmentView.Department + '</td>' +
                        '<td>' + AssessgnmentView.ShortDate + '</td>' +
                        '<td>' + AssessgnmentView.Status + '</td>' +
                        '<td>' + AssessgnmentView.Allocated + '</td>' +
                        '</tr>');
                }           
            }); $('#AssessgnmentByUser').append('</tbody>');
            $('i').remove(".fa-refresh");
            $('#AssessgnmentByUser').dataTable({
           
                destroy: true,
                responsive: true,
                paging: false,
                searching: false
            });
        },
        failure: function (msg) {
            $('#AssessgnmentByUser').text(msg);
        }
    });
};
function GetAllAssessgnmentByDepartment() {
    var obj = {};
    $.ajax({
        type: "POST",
        data: JSON.stringify(obj),
        url: "/Services/DataCollection.asmx/GetAllAssessgnmentByDepartment",
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: function (response) {
            var AssessgnmentView = response.d;
            //$('#AssessgnmentBydepartment').dataTable().fnClearTable();
            //$('#AssessgnmentBydepartment').DataTable().destroy();
            //$('#AssessgnmentBydepartment').empty();
            $('#AssessgnmentBydepartment').append('<thead><th>view</th><th>AssessmentType</th><th>SubmissionType</th><th>Name</th><th>CreatedBy</th><th>Departments</th><th>CreatedDate</th><th>Status</th><th>Allocated</th></thead><tbody>');

          $.each(AssessgnmentView, function (index, AssessgnmentView) {
              $('#Displaydata').append('<tr>' +
                    '<td style="text-align: center"><a href="/Assessment/' + AssessgnmentView.AssessmentType + '/' + AssessgnmentView.Id + '"  class="fa fa-arrow-right" style="font-weight: 700;color: green;"> Edit </a> </td>' +
         
                    '<td>' + AssessgnmentView.AssessmentType + '</td>' +
                    '<td>' + AssessgnmentView.SubmissionType + '</td>' +
                    '<td>' + AssessgnmentView.Name + '</td>' +
                    '<td>' + AssessgnmentView.CreatedBy + '</td>' +
                    '<td>' + AssessgnmentView.Departments + '</td>' +
                    '<td>' + AssessgnmentView.CreatedDate + '</td>' +
                    '<td>' + AssessgnmentView.IsDeleted + '</td>' +
                    '<td>' + AssessgnmentView.Active + '</td>' +

                    '</tr>');
            }); $('#AssessgnmentBydepartment').append('</tbody>');
            $('#AssessgnmentBydepartment').append('<tfoot> <tr onclick="ClearAssessgnmentView();"><td border="0" style="border:0px;text-align: center;" ><label  class="fa fa-plus" data-toggle="modal" data-target="#AssessgnmentViewModals"> Add New </label></td></tr></tfoot>');
            $('i').remove(".fa-refresh");
            $('#AssessgnmentBydepartment').dataTable({
                dom: "Bfrtip", buttons: [
                    { extend: "csv", className: "btn-sm" },
                    { extend: "excel", className: "btn-sm" },
                    { extend: "pdfHtml5", className: "btn-sm" },
                    { extend: "print", className: "btn-sm" }],
                destroy: true,
                responsive: true,
                paging: true,
                searching: true
            });
        },
        failure: function (msg) {
            $('#AssessgnmentBydepartment').text(msg);
        }
    });
};

function GetAllAssessgnmentByAuthorDepartment() {
    var obj = {};
    $.ajax({
        type: "POST",
        data: JSON.stringify(obj),
        url: "/Services/DataCollection.asmx/GetAllAssessgnmentByDepartment",
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: function (response) {
            var AssessgnmentView = response.d;
            $('#AssessgnmentByUser').append('<thead><th>view</th><th>AssessmentType</th><th>SubmissionType</th><th>Name</th><th>CreatedBy</th><th>Departments</th><th>CreatedDate</th><th>Status</th><th>Allocated</th></thead><tbody>');

            //$('#AssessgnmentByUser').dataTable().fnClearTable();
            //$('#AssessgnmentByUser').DataTable().destroy();
            //$('#AssessgnmentByUser').empty();
            $.each(AssessgnmentView, function (index, AssessgnmentView) {
                var Edit = "";
                if (AssessgnmentView.StatusId < 3) {
                    Edit = "Edit";
                    $('#AssessgnmentByUser').append('<tr>' +
                        '<td style="text-align: center;"><a href="/Assessment/' + AssessgnmentView.AssessmentType + '/' + AssessgnmentView.Id + '"  class="fa fa-arrow-right" style="font-weight: 700;color: green;">' + Edit + '</a> </td>' +
                        '<td>' + AssessgnmentView.AssessmentType + '</td>' +
                        '<td>' + AssessgnmentView.SubmissionType + '</td>' +
                        '<td>' + AssessgnmentView.Name + '</td>' +
                        '<td>' + AssessgnmentView.CreatedBy + '</td>' +
                        '<td>' + AssessgnmentView.Department + '</td>' +
                        '<td>' + AssessgnmentView.ShortDate + '</td>' +
                        '<td>' + AssessgnmentView.Status + '</td>' +
                        '<td>' + AssessgnmentView.Allocated + '</td>' +
                        '</tr>');
                }
                else if (AssessgnmentView.StatusId == 3) {
                    Edit = "Survey";
                    $('#AssessgnmentByUser').append('<tr>' +
                        //'<td style="text-align: center;"><a class="fa fa-arrow-right" onclick="SetSurveyAssessmentId(' + AssessgnmentView.Id + ')"  data-toggle="modal" data-target="#Surveylinq" style="font-weight: 700;color: blue;">' + Edit + '</a> </td>' +
                        '<td style="text-align: center;">' + 'Submitted' + '</td>' +
                        '<td>' + AssessgnmentView.AssessmentType + '</td>' +
                        '<td>' + AssessgnmentView.SubmissionType + '</td>' +
                        '<td>' + AssessgnmentView.Name + '</td>' +
                        '<td>' + AssessgnmentView.CreatedBy + '</td>' +
                        '<td>' + AssessgnmentView.Department + '</td>' +
                        '<td>' + AssessgnmentView.ShortDate + '</td>' +
                        '<td>' + AssessgnmentView.Status + '</td>' +
                        '<td>' + AssessgnmentView.Allocated + '</td>' +
                        '</tr>');
                }
                else if (AssessgnmentView.StatusId == 7 || AssessgnmentView.StatusId == 8) {
                    Edit = "Published";
                    $('#AssessgnmentByUser').append('<tr>' +
                        '<td style="text-align: center;"><a target="_blank" href="Documents/' + AssessgnmentView.Id + '-final.pdf"  class="fa fa-arrow-right" style="font-weight: 700;color: green;">View Report</a> <a class="fa fa-arrow-right" onclick="SetSurveyAssessmentId(' + AssessgnmentView.Id + ')"  data-toggle="modal" data-target="#Surveylinq" style="font-weight: 700;color: blue;">' + "Survey" + '</a> </td>' +
                        '<td>' + AssessgnmentView.AssessmentType + '</td>' +
                        '<td>' + AssessgnmentView.SubmissionType + '</td>' +
                        '<td>' + AssessgnmentView.Name + '</td>' +
                        '<td>' + AssessgnmentView.CreatedBy + '</td>' +
                        '<td>' + AssessgnmentView.Department + '</td>' +
                        '<td>' + AssessgnmentView.ShortDate + '</td>' +
                        '<td>' + AssessgnmentView.Status + '</td>' +
                        '<td>' + AssessgnmentView.Allocated + '</td>' +
                        '</tr>');
                }

            }); $('#AssessgnmentByUser').append('</tbody>');
            $('i').remove(".fa-refresh");
            $('#AssessgnmentByUser').dataTable({

                destroy: true,
                responsive: true,
                paging: false,
                searching: false
            });
        },
        failure: function (msg) {
            $('#AssessgnmentByUser').text(msg);
        }
    });
};


function GetAllAssessgnmentByStatus(StatusId) {
    var obj = {};
    obj.StatusId = StatusId; 
    $.ajax({
        type: "POST",
        data: JSON.stringify(obj),
        url: "/Services/DataCollection.asmx/GetAllAssessgnment",
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: function (response) {
            var List = ""; 
            var AssessgnmentView = response.d;
            //$('#Assusor_' + StatusId).dataTable().fnClearTable();
            //$('#Assusor_' + StatusId).DataTable().destroy();
            //$('#Assusor_' + StatusId).empty();
            $('#Assusor_' + StatusId).append('<thead><th>view</th><th>Department</th><th>Name</th><th>AssessmentType</th><th>SubmissionType</th><th>Status</th><th>Allocated</th><th>Quality</th><th>Date</th><th>Days</th><th>DaysLeft</th><th>CreatedBy</th></thead><tbody>');
            $.each(AssessgnmentView, function (index, AssessgnmentView) {

                var username = document.getElementById('UserName').innerHTML;
                var IsVisable = ""; 
                var IsPrintVisable = "display:none";
                var AllocateAssessment = "";  
                
                //Turn Around time (response time left for presidency to respond)
                var DaysLeft = 14;
                var ColorChange = 101;
                DaysLeft -= AssessgnmentView.DaysLapsed;
                if (AssessgnmentView.DaysLapsed > 14) {
                    DaysLeft = 0;
                    if (AssessgnmentView.DaysLapsed >= 1 || AssessgnmentView.DaysLapsed <= 3) {
                        ColorChange = 15;
                    } else if (AssessgnmentView.DaysLapsed == 0) {
                        ColorChange = 21;
                    }
                }

                //if (AssessgnmentView.StatusId > 4) {
                //    if (AssessgnmentView.AllocatedUserName == username) {
                //        IsVisable = "style=\"display:none\"";
                     
                //    }
                //}
                if (AssessgnmentView.StatusId == 4) 
                {
                    if (AssessgnmentView.AllocatedUserName != username) {
                      
                        IsVisable = "style=\"display:none\"";
                    }
                }

                if (AssessgnmentView.StatusId > 6)
                    {
                        IsPrintVisable = ""
                }


                if (AssessgnmentView.StatusId == 3   )
                {
                    AllocateAssessment = '<a   style="color:#EA4335"  onclick="SetAllocatId(' + AssessgnmentView.Id + ')"  data-toggle="modal" data-target="#AllocateAssessment" >Allocate</a> ';
                }

               

                if (AssessgnmentView.StatusId == 6) {

                    if (AssessgnmentView.AllocatedUserName != username) {

                        IsVisable = "style=\"display:none\"";
                    }

                }
                if (AssessgnmentView.StatusId == 5) {
                    AllocateAssessment = '<a   style="color:#EA4335"  onclick="SetAllocatIdQA(' + AssessgnmentView.Id + ')"  data-toggle="modal" data-target="#AllocateAssessmentQA" >Allocate</a> ';
                }

                $('#Assusor_' + StatusId).append('<tr>' +
                    '<td style="text-align: center">' + AllocateAssessment + '<a  style="color:blue" href="/assessment/' + AssessgnmentView.AssessmentType + '/' + AssessgnmentView.Id + '"  ' + IsVisable + '  class="fa fa-arrow-right" >View</a>  <a   style="color:green;' + IsPrintVisable + '"    onclick="AssessgnmentUpdate(\'' + AssessgnmentView.Id + '\',\'8\')" class="fa fa-arrow-right" >Publish</a></td > ' +
                    '<td id="AssessmentTDepartment_' + index +'" >' + AssessgnmentView.Department + '</td>' +
                    '<td id="AssessmentName_' + index +'" >' + AssessgnmentView.Name + '</td>' +
                    '<td id="AssessmentType' + index+'" >' + AssessgnmentView.AssessmentType + '</td>' +
                    '<td id="SubmissionType' + index +'" >' + AssessgnmentView.SubmissionType + '</td>' +
                    '<td id="Status' + index +'" >' + AssessgnmentView.Status + '</td>' +
                    '<td id="Allocated' + index +'" >' + AssessgnmentView.Allocated + '</td>' + 
                    '<td>' + AssessgnmentView.Quality + '</td>' + 
                    '<td>' + AssessgnmentView.ShortDate + '</td>' +
                    '<td class="percentage' + AssessgnmentView.DaysLapsed + '">' + AssessgnmentView.DaysLapsed + '</td>' +
                    '<td class="percentage' + ColorChange + '">' + DaysLeft + '</td>' +
                    '<td>' + AssessgnmentView.CreatedBy + '</td>' +
                   
             
                    '</tr>');
            }); $('#Assusor_' + StatusId).append('</tbody>');
             // $('#Assusor_' + StatusId).append('<tfoot> <tr onclick="ClearAssessgnmentView();"><td border="0" style="border:0px;text-align: center;" ><label  class="fa fa-plus" data-toggle="modal" data-target="#AssessgnmentViewModals"> Add New </label></td></tr></tfoot>');
             // $('i').remove(".fa-refresh");
            $('#Assusor_' + StatusId).dataTable({
                //dom: "Bfrtip", buttons: [
                //    { extend: "csv", className: "btn-sm" },
                //    { extend: "excel", className: "btn-sm" },
                //    { extend: "pdfHtml5", className: "btn-sm" },
                //    { extend: "print", className: "btn-sm" }],
                destroy: true,
                responsive: true,
                paging: false,
                searching: true
            });
        },
        failure: function (msg) {
            $('#Assusor_' + StatusId).text(msg);
        }
    });
};

function GetPublishedAssessgnment() {
    var obj = {};
    obj.StatusId = 8;
    $.ajax({
        type: "POST",
        data: JSON.stringify(obj),
        url: "/Services/DataCollection.asmx/GetAllAssessgnment",
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: function (response) {
            var List = "";
            var AssessgnmentView = response.d;
            $.each(AssessgnmentView, function (index, AssessgnmentView) {

                $('#PublishedReports').append('<div class="x_content"  style="border-bottom: 1px solid #1ABB9C;"  ><div class="Row"> <div class="col-md-2 col-sm-2 col-xs-2" style="border:0px solid #e5e5e5;">  <ul class="list-inline prod_color"><li><p></p><div class="color bg-green"></div></li></ul> </div> <div class="col-md-10 col-sm-10 col-xs-10" style="border:0px solid #e5e5e5;">' +
                    '<h3 class="prod_title">' + AssessgnmentView.SubmissionType+' :  <span   style="font-weight:700">' + AssessgnmentView.Name + '</span></h3>' +
                    '<p class="prod_title">Department :<span   style="font-weight:600"   >' + AssessgnmentView.Department + '</span>  <a  style="color:#1ABB9C !important"  target="_new"  href="../documents/' + AssessgnmentView.Id + '.pdf" >>>> View Report</a></p>' +
                    '<p  style="color:#1ABB9C !important"  target="_new" <input type="button" onclick="PDFExport()" value="Download"/></p>' +
                    '<p> '  +  
                    '<div class= "x_panel  Documents"   style="padding:0px;">    ' +
                    '<div class="Row">    ' +
                    '    <h2>Documents</h2>    ' +
                    '    <div id="FileUpload_' + AssessgnmentView.Id + '">         ' +
                    '    </div>   ' +
                    '</div>  ' +
                    '</div >   ' +
                    '</p > ' + 
                    ' </div></div></div>');

                GetAttachementPublished('FileUpload_' + AssessgnmentView.Id + '', 'Assessment', AssessgnmentView.Id, AssessgnmentView.Id);
              


                /* $('#Assusor_' + StatusId).append('<tr>' +
                     '<td style="text-align: center"><a  style="color:blue" href="/assessment/' + AssessgnmentView.Id + '"  ' + IsVisable + '  class="fa fa-arrow-right" >View</a> <a    style="color:orange;' + IsPrintVisable + '"  data-toggle="modal" data-target="#PrintCertificateModals" onclick="printCeriticate(\'' + AssessgnmentView.Department + '\',\'' + AssessgnmentView.AssessmentType + '\',\'' + AssessgnmentView.SubmissionType + '\',\'' + AssessgnmentView.Id + '\');" >Print</a> <a   style="color:green;' + IsPrintVisable + '"    onclick="AssessgnmentUpdate(\'' + AssessgnmentView.Id + '\',\'8\')" class="fa fa-arrow-right" >Publish</a></td > ' +
                     '<td id="AssessmentTDepartment_' + index + '" >' + AssessgnmentView.Department + '</td>' +
                     '<td id="AssessmentName_' + index + '" >' + AssessgnmentView.Name + '</td>' +
                     '<td id="AssessmentType' + index + '" >' + AssessgnmentView.AssessmentType + '</td>' +
                     '<td id="SubmissionType' + index + '" >' + AssessgnmentView.SubmissionType + '</td>' +
                     '<td id="Status' + index + '" >' + AssessgnmentView.Status + '</td>' +
                     '<td id="Allocated' + index + '" >' + AssessgnmentView.Allocated + '</td>' +
                     '<td>' + AssessgnmentView.Quality + '</td>' +
                     '<td>' + AssessgnmentView.ShortDate + '</td>' +
                     '<td class="DaysLapsed' + AssessgnmentView.DaysLapsed + '">' + AssessgnmentView.DaysLapsed + '</td>' +
                     '<td>' + AssessgnmentView.CreatedBy + '</td>' +
 
                     '</tr>');
 
 */
            });  
        },
        failure: function (msg) {
            $('#Assusor_' + StatusId).text(msg);
        }
    });
};

function GetpublishedAssessmentById(_Id) {
    var obj = {};
    obj._Id = _Id;

    $.ajax({
        type: "POST",
        data: JSON.stringify(obj),
        url: "/Services/DataCollection.asmx/GetAssessgnmentById",
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: function (response) {
            var AssessmentAnswers = response.d;
            console.log(AssessmentAnswers);
            var Answers = [];
            var Assment = AssessmentAnswers.Assment;
             Answers = AssessmentAnswers.Answers; 
            //console.log(Answers);
            $('#textarea').html(Answers[0].Content);

            
            //tinymce.get("textarea").getContent(Answers[0].Content);
            
            
           
        },
        failure: function (msg) {
            $('#DisplayData').text(msg);
        }
    });
};
function AssessgnmentUpdate(AssessmentId, StatusId) {
    var obj = {};
    obj.AssessmentId = AssessmentId;
    obj.StatusId = StatusId;

    $.ajax({
        type: "POST",
        data: JSON.stringify(obj),
        url: "/Services/DataCollection.asmx/AssessgnmentUpdate",
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: function (response) {

            if (StatusId == 8) {
                
                //window.location.replace("/");
            }

        }
        ,
        failure: function (msg) {
            $('#DisplayData').text(msg);
        }

    });
    
    if (StatusId == "8") {
        alert("Assessment published");
        window.location.replace("/");
    }

};
function SaveAllocation(AssessmentId , UserId) {
    var obj = {};
    obj.AssessmentId = AssessmentId;
    obj.UserId = UserId;
    $.ajax({
        type: "POST",
        data: JSON.stringify(obj),
        url: "/Services/DataCollection.asmx/SaveAllocation",
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: function (response) {
            var Assessment = response.d;   

        if (Assessment.Id == 4)
        {
            $('#Allocate').hide();

            $('#FirstApproved').show();
            $('#SecondApproved').hide();
        }
        else if (Assessment.StatusId == 5) {
            $('#FirstApproved').show();
            $('#SecondApproved').hide();
            $('#Assign').show();
        }
        },
        failure: function (msg) {
            $('#Assusor_' + StatusId).text(msg);
        }
    });

    //GetAllAssessgnmentByStatus(3);
    //GetAllAssessgnmentByStatus(4);
    //GetAllAssessgnmentByStatus(5);
    //GetAllAssessgnmentByStatus(6);

    window.location.replace("/");
};
function SaveAllocationQA(AssessmentId, UserId) {
    var obj = {};
    obj.AssessmentId = AssessmentId;
    obj.UserId = UserId;
    $.ajax({
        type: "POST",
        data: JSON.stringify(obj),
        url: "/Services/DataCollection.asmx/SaveAllocationQA",
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: function (response) {
            var Assessment = response.d;

            if (Assessment.Id == 4) {
                $('#Allocate').hide();

                $('#FirstApproved').show();
                $('#SecondApproved').hide();
            }
            else if (Assessment.StatusId == 5) {
                $('#FirstApproved').show();
                $('#SecondApproved').hide();
                $('#Assign').show();
            }
        },
        failure: function (msg) {
            $('#Assusor_' + StatusId).text(msg);
        }
    });

    //GetAllAssessgnmentByStatus(3);
    //GetAllAssessgnmentByStatus(4);
    //GetAllAssessgnmentByStatus(5);
    //GetAllAssessgnmentByStatus(6);

    window.location.replace("/");
};

function SaveAllocateSectorExperts(AssessmentId, UserId) {
    var obj = {};
    obj.AssessmentId = AssessmentId;
    obj.UserId = UserId;
    $.ajax({
        type: "POST",
        data: JSON.stringify(obj),
        url: "/Services/DataCollection.asmx/SaveAllocateSectorExperts",
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: function (response) {
            var Assessment = response.d;

            if (Assessment.Id == 6) {
                $('#Allocate').hide();

                $('#FirstApproved').show();
                $('#SecondApproved').hide();
            }
            else if (Assessment.StatusId == 5) {
                $('#FirstApproved').show();
                $('#SecondApproved').hide();
                $('#Assign').show();
            }
        },
        failure: function (msg) {
            $('#Assusor_' + StatusId).text(msg);
        }
    });

    GetAllAssessgnmentByStatus(3);
    GetAllAssessgnmentByStatus(4);
    GetAllAssessgnmentByStatus(5);
    GetAllAssessgnmentByStatus(6);
};



function GetAttachementsByObjectAndLinkId(ObjectId, Object, LinkId) {
    var obj = {};
    obj.LinkId = LinkId
    obj.ObjectType = Object
  
    $.ajax({
        type: "POST",
        url: "/Services/DataCollection.asmx/GetAttachementsByObjectAndLinkId",
        data: JSON.stringify(obj),
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: function (response) {
            var Attachments = response.d;
            $('#' + ObjectId).empty();
            var AttachementTable = "";
            AttachementTable = '<table class="DisplayData table table-striped jambo_table bulk_action no-footer dataTable" ><thead><tr><th>Action</th><th>Object</th><th>Name</th><th>Size</th><th>File</th><tr></thead><tbody>';
            $.each(Attachments, function (index, Attachments) {
                AttachementTable +=
                    '<tr onclick="ViewDocumentOnline(\'' + Attachments.Path + '\');"  name="btnFindEmployee" value="Find" class="fa fa-arrow-right"  data-toggle="modal" data-target="#myDocuments"><td style="width:10%;" ><label style="padding-left: 40%;"  ></label></td>' +
                    '<td w>' + Attachments.Object + '</td>' +
                    '<td>' + Attachments.Name + '</td>' +
                    '<td>' + (Attachments.Size / 1032 / 1032).toFixed(2).toString() + '(MB)</td>' +
                    '<td  ><a href="' + Attachments.Path + '" download="w3logo"> <img src="/images/Extension/' + Attachments.Extension + '.png" alt="image"></a></td></tr>';
            });
            AttachementTable += '<tr> <td > <label for="fileUpload">Select File to Upload:</label></td><td  colspan="3"><input type="file" id="fileUpload" class="form-control "></td><td><input type="button" onclick="UploadFileByLinkID(\'' + ObjectId + '\')" class="form-control btn btn-primary" value="Upload File" id="btnUploadFile"></input></td></tr>';
            AttachementTable += '<tr> <td > <label for="fileUpload">Select File to Upload:</label></td><td  colspan="3"><input type="file" id="fileUpload" class="form-control "></td><td><input type="button" onclick="UploadFileByLinkID(\'' + ObjectId + '\')" class="form-control btn btn-primary" value="Upload File" id="btnUploadFile"></input></td></tr>';
            AttachementTable += '</tbody></table>';

            $('#' + ObjectId).append(AttachementTable);
            $('i').remove(".fa-refresh");
        },
        failure: function (msg) {GetAttachementsByObjectAndLinkIdRefence
            $('#' + ObjectId).text(msg);
        }
    });

};
function GetAttachementPublished(ObjectId, Object, LinkId, Reference) {
    var obj = {};
    obj.Object = Object;
    obj.LinkId = LinkId;
    obj.Reference = Reference;

    $.ajax({
        type: "POST",
        url: "/Services/DataCollection.asmx/GetAttachementsByObjectAndLinkIdRefence",
        data: JSON.stringify(obj),
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: function (response) {
            var Attachments = response.d;
            $('#' + ObjectId).empty();
            var AttachementTable = "";
            AttachementTable = '<table class="DisplayData table table-striped jambo_table bulk_action no-footer dataTable" ><tbody>';
            $.each(Attachments, function (index, Attachments) {

                AttachementTable +=
                    '<tr name="btnFindEmployee" value="Find" class="fa fa-arrow-right" ><td style="width:10%;min-width:150px" ><label style="padding-left: 40%;"><a href="' + Attachments.Path + '" download="' + Attachments.Name + '">Download</a></label></td>' +
                    '<td>' + Attachments.Object + '</td>' +
                    '<td>' + Attachments.Name + '</td>' +
                    '<td>' + (Attachments.Size / 1032 / 1032).toFixed(2).toString() + '(MB)</td>' +
                '<td > <img src="/images/Extension/' + Attachments.Extension + '.png" alt="image"></td></tr>';
            });
            AttachementTable += '</tbody></table>';

            $('#' + ObjectId).append(AttachementTable);
            $('i').remove(".fa-refresh");
        },
        failure: function (msg) {
            $('#' + ObjectId).text(msg);
        }
    });

};

function GetAttachementsByObjectAndLinkIdReference(ObjectId, Object, LinkId, Reference) {
    var obj = {};
    obj.Object = Object;
    obj.LinkId = LinkId;
    obj.Reference = Reference;

    $.ajax({
        type: "POST",
        url: "/Services/DataCollection.asmx/GetAttachementsByObjectAndLinkIdRefence",
        data: JSON.stringify(obj),
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: function (response) {
            var Attachments = response.d;
            $('#' + ObjectId).empty();
            var AttachementTable = "";
            AttachementTable = '<table class="DisplayData table table-striped jambo_table bulk_action no-footer dataTable" ><thead><tr><th>Action</th><th>Object</th><th>Name</th><th>Size</th><th>File</th><tr></thead><tbody>';
            $.each(Attachments, function (index, Attachments) {
                AttachementTable +=
                    '<tr onclick="ViewDocumentOnline(\'' + Attachments.Path + '\');"  name="btnFindEmployee" value="Find" class="fa fa-arrow-right"  data-toggle="modal" data-target="#myDocuments"><td style="width:10%;" ><label style="padding-left: 40%;"  >View</label></td>' +
                    '<td>' + Attachments.Object + '</td>' +
                    '<td>' + Attachments.Name + '</td>' +
                    '<td>' + (Attachments.Size / 1032 / 1032).toFixed(2).toString() + '(MB)</td>' +
                    '<td  ><a href="' + Attachments.Path + '" download="w3logo"> <img src="/images/Extension/' + Attachments.Extension + '.png" alt="image"></a></td></tr>';
            });
            AttachementTable += '<tr  Class="EnableUpload"> <td > <label for="fileUpload">Select File to Upload:</label></td><td  colspan="3"><input type="file" id="fileUpload" class="form-control "></td><td><input type="button" onclick="UploadFileByRefernce(\'' + ObjectId + '\',\'' + Object + '\',\'' + LinkId + '\',\'' + Reference + '\')" class="form-control btn btn-primary" value="Upload File" id="btnUploadFile"></input></td></tr>';
            AttachementTable += '<tr  Class="EnableUpload"> <td > <label for="fileUpload2">Uploading additional documents:</label></td><td  colspan="3"><input type="file" id="fileUpload2" class="form-control "></td><td><input type="button" onclick="UploadAdditionalFileByRefernce(\'' + ObjectId + '\',\'' + Object + '\',\'' + LinkId + '\',\'' + Reference + '\')" class="form-control btn btn-primary" value="Upload Additional Document" id="btnUploadFile2"></input></td></tr>';
            AttachementTable += '</tbody></table>';

            $('#' + ObjectId).append(AttachementTable);
            $('i').remove(".fa-refresh");
        },
        failure: function (msg) {
            $('#' + ObjectId).text(msg);
        }
    });

};
function UploadFile(ControlID) {

    console.log('file fffgfgfg');
    alert('File gfgfgffgfg');
    var data = new FormData();
    var files = $("#fileUpload").get(0).files;
    var numFiles = $("#fileUpload").get(0).files.length;

    alert(numFiles);
    var pathArray = window.location.pathname.split('/');

    var Object = pathArray[pathArray.length - 2]
    var LinkID = pathArray[pathArray.length - 1]
    // Add the uploaded image content to the form data collection
    if (files.length > 0) {
        data.append("UploadedImage", files[0]);
        data.append("FileType", Object);
        data.append("LinkID", LinkID);
    }

    // Make Ajax request with the contentType = false, and procesDate = false
    var ajaxRequest = $.ajax({
        type: "POST",
        url: "/api/fileupload/uploadfile",
        contentType: false,
        processData: false,
        data: data
    });

    ajaxRequest.done(function (responseData, textStatus) {
        if (textStatus == 'success') {
            if (responseData != null) {
                if (responseData.Key) {

                    GetAllAttachmentsByLinkID(ControlID, LinkID);

                    // alert(responseData.Value);
                    $("#fileUpload").val('');
                } else {
                    alert(responseData.Value);
                }
            }
        } else {
            alert(responseData.Value);
        }
    });
};
function UploadFileByLinkID(ControlID, Object, LinkID) {

    console.log('file upload');
    alert('File uploaded');
    var data = new FormData();
    var files = $("#fileUpload").get(0).files;
    if (parseInt($fileUpload.get(0).files.length) > 5) {
        alert("You can only upload a maximum of 5 files");
    }
    var pathArray = window.location.pathname.split('/');

    //var Object = pathArray[pathArray.length - 2]
    //var LinkID = pathArray[pathArray.length - 1]
    // Add the uploaded image content to the form data collection
    if (files.length > 0) {
        data.append("UploadedImage", files[0]);
        data.append("FileType", Object);
        data.append("LinkID", LinkID);
    }

    // Make Ajax request with the contentType = false, and procesDate = false
    var ajaxRequest = $.ajax({
        type: "POST",
        url: "/api/fileupload/uploadfile",
        contentType: false,
        processData: false,
        data: data
    });

    ajaxRequest.done(function (responseData, textStatus) {
        if (textStatus == 'success') {
            if (responseData != null) {
                if (responseData.Key) {

                    GetAttachementsByObjectAndLinkId(ControlID, Object, LinkID);

                    // alert(responseData.Value);
                    $("#fileUpload").val('');
                } else {
                    alert(responseData.Value);
                }
            }
        } else {
            alert(responseData.Value);
        }
    });
};

function UploadFileByRefernce(ControlID, Object, LinkID, Refernce) {
    var data = new FormData();

    var files = $("#fileUpload").get(0).files;

    var pathArray = window.location.pathname.split('/');

    //var Object = pathArray[pathArray.length - 2]
    //var LinkID = pathArray[pathArray.length - 1]
    // Add the uploaded image content to the form data collection
    if (files.length > 0) {
        data.append("UploadedImage", files[0]);
        data.append("FileType", Object);
        data.append("LinkID", LinkID);
        data.append("Refernce", Refernce);
    }

    // Make Ajax request with the contentType = false, and procesDate = false
    var ajaxRequest = $.ajax({
        type: "POST",
        url: "/api/fileupload/uploadfile",
        contentType: false,
        processData: false,
        data: data
    });

    ajaxRequest.done(function (responseData, textStatus) {
        if (textStatus == 'success') {
            if (responseData != null) {
                if (responseData.Key) {

                    GetAttachementsByObjectAndLinkIdReference(ControlID, Object, LinkID, Refernce);

                    // alert(responseData.Value);
                    $("#fileUpload").val('');
                } else {
                    alert(responseData.Value);
                }
            }
        } else {
            alert(responseData.Value);
        }
    });
};

function UploadAdditionalFileByRefernce(ControlID, Object, LinkID, Refernce) {
    var data = new FormData();

    var files = $("#fileUpload2").get(0).files;

    var pathArray = window.location.pathname.split('/');

    //var Object = pathArray[pathArray.length - 2]
    //var LinkID = pathArray[pathArray.length - 1]
    // Add the uploaded image content to the form data collection
    if (files.length > 0) {
        data.append("UploadedImage", files[0]);
        data.append("FileType", Object);
        data.append("LinkID", LinkID);
        data.append("Refernce", Refernce);
    }

    // Make Ajax request with the contentType = false, and procesDate = false
    var ajaxRequest = $.ajax({
        type: "POST",
        url: "/api/fileupload/uploadfile",
        contentType: false,
        processData: false,
        data: data
    });

    ajaxRequest.done(function (responseData, textStatus) {
        if (textStatus == 'success') {
            if (responseData != null) {
                if (responseData.Key) {

                    GetAttachementsByObjectAndLinkIdReference(ControlID, Object, LinkID, Refernce);

                    // alert(responseData.Value);
                    $("#fileUpload2").val('');
                } else {
                    alert(responseData.Value);
                }
            }
        } else {
            alert(responseData.Value);
        }
    });
};

$(function () {
    $("input[type='submit']").click(function () {
        var $fileUpload = $("input[type='files']");
        if (parseInt($fileUpload.get(0).files.length) > 5) {
            alert("You can only upload a maximum of 5 files");
        }
    });
});
function documentTypes(Type) {

    return '<img style="display: block;" src="/images/elements/' + Type + '.png" alt="image" />';

}
function ViewDocumentOnline(FileLocation) {

    $('#DocumentOnline').empty();
    $('#DocumentOnline').append('<object data="' + FileLocation + '\" type=\"application/pdf\" width=\"100%\" height=\"600px\">'
        + '<iframe src="' + FileLocation + '\" width=\"100%\" height=\"100%\" style=\"border: none;\">This browser does not support PDFs. Please download the PDF to view it: <a href="' + FileLocation + '\">Download PDF</a>'
        + '</iframe></object>');

}



function GetAllAssessgnmentTypes() {
    var obj = {};
    $.ajax({
        type: "POST",
        data: JSON.stringify(obj),
        url: "/Services/DataCollection.asmx/GetAllAssessgnmentTypes",
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: function (response) {
            var AssessgnmentTypes = response.d;
            $('#DisplayData').dataTable().fnClearTable();
            $('#DisplayData').DataTable().destroy();
            $('#DisplayData').empty();
            $('#DisplayData').append('<thead><th>view</th><th>Id</th><th>Name</th></thead><tbody>');
            $.each(AssessgnmentTypes, function (index, AssessgnmentTypes) {
                $('#DisplayData').append('<tr>' +
                    '<td style="text-align: center"><label onclick="GetAssessgnmentTypesById(' + AssessgnmentTypes.Id + ');"  class="fa fa-arrow-right" data-toggle="modal" data-target="#AssessgnmentTypesModals" style="font-weight: 700;color: green;"> Edit </label> | <label style="font-weight: 700;color: red;" class="fa fa-close" onclick="DeleteAssessgnmentTypes(' + AssessgnmentTypes.Id + ')" >Delete</label></td>' +
                    '<td>' + AssessgnmentTypes.Id + '</td>' +
                    '<td>' + AssessgnmentTypes.Name + '</td>' +

                    '</tr>');
            }); $('#DisplayData').append('</tbody>');
            $('#DisplayData').append('<tfoot> <tr onclick="ClearAssessgnmentTypes();"><td border="0" style="border:0px;text-align: center;" ><label  class="fa fa-plus" data-toggle="modal" data-target="#AssessgnmentTypesModals"> Add New </label></td></tr></tfoot>');
            $('i').remove(".fa-refresh");
            $('#DisplayData').dataTable({
                dom: "Bfrtip", buttons: [
                    { extend: "csv", className: "btn-sm" },
                    { extend: "excel", className: "btn-sm" },
                    { extend: "pdfHtml5", className: "btn-sm" },
                    { extend: "print", className: "btn-sm" }],
                destroy: true,
                responsive: true,
                paging: true,
                searching: true
            });
        },
        failure: function (msg) {
            $('#DisplayData').text(msg);
        }
    });
};
function GetAssessgnmentTypesById(AssessgnmentTypesId) {
    ClearAssessgnmentTypes();
    var obj = {};
    obj._Id = AssessgnmentTypesId;


    $.ajax({
        type: "POST",
        url: "/Services/DataCollection.asmx/GetAssessgnmentTypesById",
        data: JSON.stringify(obj),
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: function (response) {
            var AssessgnmentTypes = response.d;
            try {
                document.getElementById('AssessgnmentTypes_Id').innerHTML = AssessgnmentTypes.Id;
                document.getElementById('AssessgnmentTypes_Name').value = AssessgnmentTypes.Name;

            }
            catch (exception) {
            }
        },
        failure: function (msg) {
            $('#Erroroutput').text(msg);
        }
    });
}
function SaveAssessgnmentTypes() {
    var obj = {};
    obj.Id = document.getElementById('AssessgnmentTypes_Id').innerHTML;
    obj.Name = document.getElementById('AssessgnmentTypes_Name').value;

    $.ajax({
        type: "POST",
        url: "/Services/DataCollection.asmx/SaveAssessgnmentTypes",
        data: "{ _AssessgnmentTypes:" + JSON.stringify(obj) + "}",
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: function (response) {
            var Mess = response.d;
            if (Mess.Message == 'Saved') {
                document.getElementById('AssessgnmentTypes_Id').innerHTML = Mess.Id;
                document.getElementById('AssessgnmentTypesStatusUpdateMessgae').innerHTML = Mess.Message;
                GetAllAssessgnmentTypes();
            }
        },
        failure: function (msg) {
            document.getElementById('AssessgnmentTypesStatusUpdateMessgae').innerHTML = msg;
        }
    });
}
function DeleteAssessgnmentTypes(_Id) {
    var obj = {};
    obj._Id = _Id;
    $.ajax({
        type: "POST",
        url: "/Services/DataCollection.asmx/DeleteAssessgnmentTypes",
        data: JSON.stringify(obj),
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: function (response) {
            GetAllAssessgnmentTypes();
        },
        failure: function (msg) {
        }
    });
}
function ClearAssessgnmentTypes() {
    document.getElementById('AssessgnmentTypesStatusUpdateMessgae').innerHTML = '';
    document.getElementById('AssessgnmentTypes_Id').innerHTML = '0';
    document.getElementById('AssessgnmentTypes_Name').value = '';

}; 



function GetAllReportPRogressView() {
    var obj = {};
    $.ajax({
        type: "POST",
        data: JSON.stringify(obj),
        url: "/Services/DataCollection.asmx/GetAllReportPRogressView",
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: function (response) {
            var ReportPRogressView = response.d;
            $('#DisplayData').dataTable().fnClearTable();
            $('#DisplayData').DataTable().destroy();
            $('#DisplayData').empty();
            $('#DisplayData').append('<thead><th style="text-align: center; display:none">view</th><th>Department</th><th>Assessment Type</th><th>Assessment Version</th><th>Submission Type</th><th>DaysLapsed</th><th>Proposal Name</th><th>Submission</th><th>Feedback Date</th><th>Approved</th><th>Sign-off Type</th><th>Published</th><th>Allocated</th><th>View</th></thead><tbody>');
            $.each(ReportPRogressView, function (index, ReportPRogressView) {

                if (ReportPRogressView.Published == null) {
                    $('#DisplayData').append('<tr>' +
                        '<td style="text-align: center; display:none"><label onclick="GetReportPRogressViewById(' + ReportPRogressView.Id + ');"  class="fa fa-arrow-right" data-toggle="modal" data-target="#ReportPRogressViewModals" style="font-weight: 700;color: green;"> Edit </label> | <label style="font-weight: 700;color: red;" class="fa fa-close" onclick="DeleteReportPRogressView(' + ReportPRogressView.Id + ')" >Delete</label></td>' +
                        '<td>' + ReportPRogressView.Department + '</td>' +
                        '<td>' + ReportPRogressView.AssessmentType + '</td>' +
                        '<td>' + ReportPRogressView.AssessmentVersion + '</td>' +
                        '<td>' + ReportPRogressView.SubmissionType + '</td>' +
                        '<td class="percentage' + ReportPRogressView.DaysLapsed + '" >' + ReportPRogressView.DaysLapsed + '</td>' +
                        '<td>' + ReportPRogressView.Name + '</td>' +
                        '<td>' + ReportPRogressView.Created + '</td>' +
                        '<td>' + ReportPRogressView.Approved + '</td>' +
                        '<td>' + ReportPRogressView.Approved + '</td>' +
                        '<td>' + ReportPRogressView.SignoffType + '</td>' +
                        '<td>' + ReportPRogressView.Published + '</td>' +
                        '<td>' + ReportPRogressView.Assigned + '</td>' +
                        '<td>' + '' + '</td>' +
                        '</tr>');
                } else {
                    $('#DisplayData').append('<tr>' +
                        '<td style="text-align: center; display:none"><label onclick="GetReportPRogressViewById(' + ReportPRogressView.Id + ');"  class="fa fa-arrow-right" data-toggle="modal" data-target="#ReportPRogressViewModals" style="font-weight: 700;color: green;"> Edit </label> | <label style="font-weight: 700;color: red;" class="fa fa-close" onclick="DeleteReportPRogressView(' + ReportPRogressView.Id + ')" >Delete</label></td>' +
                        '<td>' + ReportPRogressView.Department + '</td>' +
                        '<td>' + ReportPRogressView.AssessmentType + '</td>' +
                        '<td>' + ReportPRogressView.AssessmentVersion + '</td>' +
                        '<td>' + ReportPRogressView.SubmissionType + '</td>' +
                        '<td class="percentage' + ReportPRogressView.DaysLapsed + '" >' + ReportPRogressView.DaysLapsed + '</td>' +
                        '<td>' + ReportPRogressView.Name + '</td>' +
                        '<td>' + ReportPRogressView.Created + '</td>' +
                        '<td>' + ReportPRogressView.Approved + '</td>' +
                        '<td>' + ReportPRogressView.Approved + '</td>' +
                        '<td>' + ReportPRogressView.SignoffType + '</td>' +
                        '<td>' + ReportPRogressView.Published + '</td>' +
                        '<td>' + ReportPRogressView.Assigned + '</td>' +
                        '<td style="text-align: center;"><a target="_blank" href="../Documents/' + ReportPRogressView.AssessmentId + '-final.pdf"  class="fa fa-arrow-right" style="font-weight: 700;color: green;">View Report</a> </td>' +
                        '</tr>');
                }

            }); $('#DisplayData').append('</tbody>');
            $('#DisplayData').append('<tfoot> <tr onclick="ClearReportPRogressView();"><td border="0" style="border:0px;text-align: center;" ><label  class="fa fa-plus" data-toggle="modal" hidden=true  data-target="#ReportPRogressViewModals"> Add New </label></td></tr></tfoot>');
            $('i').remove(".fa-refresh");
            $('#DisplayData').dataTable({
                dom: "Bfrtip", buttons: [
                    { extend: "csv", className: "btn-sm" },
                    { extend: "excel", className: "btn-sm" },
                    { extend: "pdfHtml5", className: "btn-sm" },
                    { extend: "print", className: "btn-sm" }],
                destroy: true,
                responsive: true,
                paging: false,
                searching: true
            });
        },
        failure: function (msg) {
            $('#DisplayData').text(msg);
        }
    });
}; 


function SetAllocatId(Id) {
    document.getElementById('Allocate_Id').innerHTML = Id;
}; 

function SetAllocatIdQA(Id) {
    document.getElementById('AllocateQA_Id').innerHTML = Id;
}; 

function SetSurveyAssessmentId(Id) {
    document.getElementById('SurveyAssessment_Id').innerHTML = Id;
}; 

function PDFExport(assmntId) {
    $('#loading').css({ 'visibility': 'visible' });
    var obj = {};
    obj._assmntId = assmntId;
    obj._content = tinymce.get("textarea").getContent();
    //obj._UserId = UserId;

    //alert(obj._assmntId);
    //alert(obj._UserId);

    var pathArray = window.location.pathname.split('/');
    var fType = pathArray[pathArray.length - 1];
    var obj2 = {}
    obj2.AssessmentID = fType;
    obj2.AssessmentID = fType;
    //obj.Q_1_1 = tinyMCE.get('Purpose').getContent();
    obj2.Q_1_1 = tinymce.get("textarea").getContent();
    //alert(obj.Q_1_1);


                $.ajax({
                    type: "POST",
                    url: "/Services/DataCollection.asmx/PDFExport",
                    data: JSON.stringify(obj),
                    contentType: "application/json; charset=utf-8",
                    dataType: "json",
                    success: function (response2) {

                        window.open("http://" + window.location.host + "/Documents/" + response2['d']['Message'], '_new');
                        $('#loading').css({ 'visibility': 'hidden' });
                    },
                    failure: function (msg) {
                    }
                });
        


}; 

function Final_PDFExport(assmntId) {

    $('#loading').css({'visibility': 'visible'});
    document.getElementById('cancel').style = "pointer-events:none";
    document.getElementById('submit').style = "pointer-events:none";

    var obj = {};
    obj._assmntId = assmntId;
    obj._approvalType = $("#approvalType").val();
    obj._approvaltextarea = $("#approvaltextarea").val();
    obj._content = tinymce.get("textarea").getContent();
    //obj._UserId = UserId;

    //alert(obj._assmntId);
    //alert(obj._UserId);

    var pathArray = window.location.pathname.split('/');
    var fType = pathArray[pathArray.length - 1];

    //alert(obj.Q_1_1);


    $.ajax({
        type: "POST",
        url: "/Services/DataCollection.asmx/Final_PDFExport",
        data: JSON.stringify(obj),
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: function (response2) {

            window.open("http://" + window.location.host + "/Documents/" + response2['d']['Message'], '_new');
         
            AssessgnmentUpdate(fType, 7);
            document.getElementById('cancel').style = "pointer-events:auto";
            document.getElementById('submit').style = "pointer-events:auto";
            window.location = "/";

        },
        failure: function (msg) {
        }
    });



}; 