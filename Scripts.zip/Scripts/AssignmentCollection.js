﻿
function GetAllQustionnaire() {
    var obj = {};
    $.ajax({
        type: "POST",
        data: JSON.stringify(obj),
        url: "/Services/DataCollection.asmx/GetAllQustionnaire",
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: function (response) {
            var Qustionnaire = response.d;
            $('#DisplayData').dataTable().fnClearTable();
            $('#DisplayData').DataTable().destroy();
            $('#DisplayData').empty();
            $('#DisplayData').append('<thead><th>view</th><th>Id</th><th>Name</th></thead><tbody>');
            $.each(Qustionnaire, function (index, Qustionnaire) {
                $('#DisplayData').append('<tr>' +
                    '<td style="text-align: center"><label onclick="GetQustionnaireById(' + Qustionnaire.Id + ');"  class="fa fa-arrow-right" data-toggle="modal" data-target="#QustionnaireModals" style="font-weight: 700;color: green;"> Edit </label> | <label style="font-weight: 700;color: red;" class="fa fa-close" onclick="DeleteQustionnaire(' + Qustionnaire.Id + ')" >Delete</label></td>' +
                    '<td>' + Qustionnaire.Id + '</td>' +
                    '<td>' + Qustionnaire.Name + '</td>' +

                    '</tr>');
            }); $('#DisplayData').append('</tbody>');
            $('#DisplayData').append('<tfoot> <tr onclick="ClearQustionnaire();"><td border="0" style="border:0px;text-align: center;" ><label  class="fa fa-plus" data-toggle="modal" data-target="#QustionnaireModals"> Add New </label></td></tr></tfoot>');
            $('i').remove(".fa-refresh");
            $('#DisplayData').dataTable({
                dom: "Bfrtip", buttons: [
                    { extend: "csv", className: "btn-sm" },
                    { extend: "excel", className: "btn-sm" },
                    { extend: "pdfHtml5", className: "btn-sm" },
                    { extend: "print", className: "btn-sm" }],
                destroy: true,
                responsive: true,
                paging: true,
                searching: true
            });
        },
        failure: function (msg) {
            $('#DisplayData').text(msg);
        }
    });
};
function GetQustionnaireById(QustionnaireId) {
    ClearQustionnaire();
    var obj = {};
    obj._Id = QustionnaireId;


    $.ajax({
        type: "POST",
        url: "/Services/DataCollection.asmx/GetQustionnaireById",
        data: JSON.stringify(obj),
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: function (response) {
            var Qustionnaire = response.d;
            try {
                document.getElementById('Qustionnaire_Id').innerHTML = Qustionnaire.Id;
                document.getElementById('Qustionnaire_Name').value = Qustionnaire.Name;

            }
            catch (exception) {
            }
        },
        failure: function (msg) {
            $('#Erroroutput').text(msg);
        }
    });
}
function SaveQustionnaire() {
    var obj = {};
    obj.Id = document.getElementById('Qustionnaire_Id').innerHTML;
    obj.Name = document.getElementById('Qustionnaire_Name').value;
    $.ajax({
        type: "POST",
        url: "/Services/DataCollection.asmx/SaveQustionnaire",
        data: "{ _Qustionnaire:" + JSON.stringify(obj) + "}",
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: function (response) {
            var Mess = response.d;
            if (Mess.Message == 'Saved') {
                document.getElementById('Qustionnaire_Id').innerHTML = Mess.Id;
                document.getElementById('QustionnaireStatusUpdateMessgae').innerHTML = Mess.Message;
                GetAllQustionnaire();
            }
        },
        failure: function (msg) {
            document.getElementById('QustionnaireStatusUpdateMessgae').innerHTML = msg;
        }
    });
}
function DeleteQustionnaire(_Id) {
    var obj = {};
    obj._Id = _Id;
    $.ajax({
        type: "POST",
        url: "/Services/DataCollection.asmx/DeleteQustionnaire",
        data: JSON.stringify(obj),
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: function (response) {
            GetAllQustionnaire();
        },
        failure: function (msg) {
        }
    });
}
function ClearQustionnaire() {
    document.getElementById('QustionnaireStatusUpdateMessgae').innerHTML = '';
    document.getElementById('Qustionnaire_Id').innerHTML = '0';
    document.getElementById('Qustionnaire_Name').value = '';

}; 


function GetAssignmentById(AssignmentId) {
    ClearAssignment();
    var obj = {};
    obj._Id = AssignmentId;


    $.ajax({
        type: "POST",
        url: "/Services/DataCollection.asmx/GetAssignmentById",
        data: JSON.stringify(obj),
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: function (response) {
            var Assignment = response.d;
            try {
                document.getElementById('Assignment_Id').innerHTML = Assignment.Id;
                document.getElementById('Assignment_Name').value = Assignment.Name;
                document.getElementById('Assignment_Type').value = Assignment.Type;

            }
            catch (exception) {
            }
        },
        failure: function (msg) {
            $('#Erroroutput').text(msg);
        }
    });
}
function SaveAssignment() {
    var obj = {};
    obj.Id = document.getElementById('Assignment_Id').innerHTML;
    obj.Name = document.getElementById('Assignment_Name').value;
    obj.Type = document.getElementById('Assignment_Type').value;

    $.ajax({
        type: "POST",
        url: "/Services/DataCollection.asmx/SaveAssignment",
        data: "{ _Assignment:" + JSON.stringify(obj) + "}",
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: function (response) {
            var Mess = response.d;
            if (Mess.Message == 'Saved') {
                document.getElementById('Assignment_Id').innerHTML = Mess.Id;
                document.getElementById('AssignmentStatusUpdateMessgae').innerHTML = Mess.Message;
                GetAllAssignment();
            }
        },
        failure: function (msg) {
            document.getElementById('AssignmentStatusUpdateMessgae').innerHTML = msg;
        }
    });
}
function DeleteAssignment(_Id) {
    var obj = {};
    obj._Id = _Id;
    $.ajax({
        type: "POST",
        url: "/Services/DataCollection.asmx/DeleteAssignment",
        data: JSON.stringify(obj),
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: function (response) {
            GetAllAssignment();
        },
        failure: function (msg) {
        }
    });
}
function ClearAssignment() {
    document.getElementById('AssignmentStatusUpdateMessgae').innerHTML = '';
    document.getElementById('Assignment_Id').innerHTML = '0';
    document.getElementById('Assignment_Name').value = '';
    document.getElementById('Assignment_Type').value = '';

}; 

function GetAllSubsection() {
    var obj = {};
    $.ajax({
        type: "POST",
        data: JSON.stringify(obj),
        url: "/Services/DataCollection.asmx/GetAllSubsection",
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: function (response) {
            var Subsection = response.d;
            $('#DisplayData').dataTable().fnClearTable();
            $('#DisplayData').DataTable().destroy();
            $('#DisplayData').empty();
            $('#DisplayData').append('<thead><th>view</th><th>Id</th><th>Name</th><th>Type</th></thead><tbody>');
            $.each(Subsection, function (index, Subsection) {
                $('#DisplayData').append('<tr>' +
                    '<td style="text-align: center"><label onclick="GetSubsectionById(' + Subsection.Id + ');"  class="fa fa-arrow-right" data-toggle="modal" data-target="#SubsectionModals" style="font-weight: 700;color: green;"> Edit </label> | <label style="font-weight: 700;color: red;" class="fa fa-close" onclick="DeleteSubsection(' + Subsection.Id + ')" >Delete</label></td>' +
                    '<td>' + Subsection.Id + '</td>' +
                    '<td>' + Subsection.Name + '</td>' +
                    '<td>' + Subsection.Type + '</td>' +

                    '</tr>');
            }); $('#DisplayData').append('</tbody>');
            $('#DisplayData').append('<tfoot> <tr onclick="ClearSubsection();"><td border="0" style="border:0px;text-align: center;" ><label  class="fa fa-plus" data-toggle="modal" data-target="#SubsectionModals"> Add New </label></td></tr></tfoot>');
            $('i').remove(".fa-refresh");
            $('#DisplayData').dataTable({
                dom: "Bfrtip", buttons: [
                    { extend: "csv", className: "btn-sm" },
                    { extend: "excel", className: "btn-sm" },
                    { extend: "pdfHtml5", className: "btn-sm" },
                    { extend: "print", className: "btn-sm" }],
                destroy: true,
                responsive: true,
                paging: true,
                searching: true
            });
        },
        failure: function (msg) {
            $('#DisplayData').text(msg);
        }
    });
};
function GetSubsectionById(SubsectionId) {
    ClearSubsection();
    var obj = {};
    obj._Id = SubsectionId;


    $.ajax({
        type: "POST",
        url: "/Services/DataCollection.asmx/GetSubsectionById",
        data: JSON.stringify(obj),
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: function (response) {
            var Subsection = response.d;
            try {
                document.getElementById('Subsection_Id').innerHTML = Subsection.Id;
                document.getElementById('Subsection_Name').value = Subsection.Name;
                document.getElementById('Subsection_Type').value = Subsection.Type;

            }
            catch (exception) {
            }
        },
        failure: function (msg) {
            $('#Erroroutput').text(msg);
        }
    });
}
function SaveSubsection() {
    var obj = {};
    obj.Id = document.getElementById('Subsection_Id').innerHTML;
    obj.Name = document.getElementById('Subsection_Name').value;
    obj.Type = document.getElementById('Subsection_Type').value;

    $.ajax({
        type: "POST",
        url: "/Services/DataCollection.asmx/SaveSubsection",
        data: "{ _Subsection:" + JSON.stringify(obj) + "}",
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: function (response) {
            var Mess = response.d;
            if (Mess.Message == 'Saved') {
                document.getElementById('Subsection_Id').innerHTML = Mess.Id;
                document.getElementById('SubsectionStatusUpdateMessgae').innerHTML = Mess.Message;
                GetAllSubsection();
            }
        },
        failure: function (msg) {
            document.getElementById('SubsectionStatusUpdateMessgae').innerHTML = msg;
        }
    });
}
function DeleteSubsection(_Id) {
    var obj = {};
    obj._Id = _Id;
    $.ajax({
        type: "POST",
        url: "/Services/DataCollection.asmx/DeleteSubsection",
        data: JSON.stringify(obj),
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: function (response) {
            GetAllSubsection();
        },
        failure: function (msg) {
        }
    });
}
function ClearSubsection() {
    document.getElementById('SubsectionStatusUpdateMessgae').innerHTML = '';
    document.getElementById('Subsection_Id').innerHTML = '0';
    document.getElementById('Subsection_Name').value = '';
    document.getElementById('Subsection_Type').value = '';

}; 


function GetQuestionsById(QuestionsId) {
    var obj = {};
    obj._Id = QuestionsId;


    $.ajax({
        type: "POST",
        url: "/Services/DataCollection.asmx/GetQuestionsById",
        data: JSON.stringify(obj),
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: function (response) {
            var Questions = response.d;
            try {
                document.getElementById('Questions_Id').innerHTML = Questions.Id;
                document.getElementById('Questions_TypeId').value = Questions.TypeId;
                document.getElementById('Questions_SubsectionId').value = Questions.SubsectionId;
                document.getElementById('Questions_Description').value = Questions.Description;
                document.getElementById('Questions_OrderId').value = Questions.Order;
            }
            catch (exception) {
            }
        },
        failure: function (msg) {
            $('#Erroroutput').text(msg);
        }
    });
}
//Survey edit function
function GetSurveyById(SurveyId) {
    var obj = {};
    obj._Id = SurveyId;
    $.ajax({
        type: "POST",
        url: "/Services/DataCollection.asmx/GetSurveyById",
        data: JSON.stringify(obj),
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: function (response) {
            var Surveys = response.d;
            try {
                document.getElementById('Survey_Id').innerHTML = Surveys.Id;
                document.getElementById('Survey_Name').value = Surveys.Name;
                document.getElementById('Survey_Active').value = Surveys.Active;
                document.getElementById('Survey_IsDeleted').value = Surveys.IsDeleted;
                document.getElementById('Survey_ActiveAssessgnmentDiv').value = Surveys.AssessgnmentId;
            }
            catch (exception) {
            }
        },
        failure: function (msg) {
            $('#Erroroutput').text(msg);
        }
    });
}

function GetReportViewById(SurveyId) {
    var obj = {};
    obj._Id = SurveyId;
    $.ajax({
        type: "POST",
        url: "/Services/DataCollection.asmx/GetReportViewById",
        data: JSON.stringify(obj),
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: function (response) {
            var Surveys = response.d;
            try {
                document.getElementById('Survey_Id').innerHTML = Surveys.Id;
                document.getElementById('Survey_Name').value = Surveys.Name;
                document.getElementById('Survey_Active').value = Surveys.Active;
                document.getElementById('Survey_IsDeleted').value = Surveys.IsDeleted;
                document.getElementById('Survey_ActiveAssessgnmentDiv').value = Surveys.AssessgnmentId;
            }
            catch (exception) {
            }
        },
        failure: function (msg) {
            $('#Erroroutput').text(msg);
        }
    });
}

//SurveyQuestion edit
function GetSurveyQuestionById(SurveyQuestionsId) {
    var obj = {};
    obj._Id = SurveyQuestionsId;
    $.ajax({
        type: "POST",
        url: "/Services/DataCollection.asmx/GetSurveyQuestionById",
        data: JSON.stringify(obj),
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: function (response) {
            var SurveyQuestions = response.d;
            try {
                document.getElementById('SurveyQuestions_Id').innerHTML = SurveyQuestions.Id;
                document.getElementById('SurveyQuestions_SurveyId').value = SurveyQuestions.SurveyId;
                document.getElementById('SurveyQuestions_Question').value = SurveyQuestions.Question;
                document.getElementById('SurveyQuestions_Rate').value = SurveyQuestions.Rate;                
            }
            catch (exception) {
            }
        },
        failure: function (msg) {
            $('#Erroroutput').text(msg);
        }
    });
}

function SaveQuestions() {
    var obj = {};
    obj.Id = document.getElementById('Questions_Id').innerHTML;
    obj.TypeId = document.getElementById('Questions_TypeId').value;
    obj.SubsectionId = document.getElementById('Questions_SubsectionId').value;
    obj.Description = document.getElementById('Questions_Description').value;
    obj.Order = document.getElementById('Questions_OrderId').value;

    $.ajax({
        type: "POST",
        url: "/Services/DataCollection.asmx/SaveQuestions",
        data: "{ _Questions:" + JSON.stringify(obj) + "}",
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: function (response) {
            var Mess = response.d;
            if (Mess.Message == 'Saved') {
                document.getElementById('Questions_Id').innerHTML = Mess.Id;
                document.getElementById('QuestionsStatusUpdateMessgae').innerHTML = Mess.Message;
                GetAllQuestions();
            }
        },
        failure: function (msg) {
            document.getElementById('QuestionsStatusUpdateMessgae').innerHTML = msg;
        }
    });
}
function DeleteQuestions(_Id) {
    var obj = {};
    obj._Id = _Id;
    $.ajax({
        type: "POST",
        url: "/Services/DataCollection.asmx/DeleteQuestions",
        data: JSON.stringify(obj),
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: function (response) {
            GetAllQuestions();
        },
        failure: function (msg) {
        }
    });
}
function ClearQuestions() {
    document.getElementById('QuestionsStatusUpdateMessgae').innerHTML = '';
    document.getElementById('Questions_Id').innerHTML = '0';
    document.getElementById('Questions_TypeId').value = '';
    document.getElementById('Questions_SubsectionId').value = '';
    document.getElementById('Questions_Description').value = '';
    document.getElementById('Questions_OrderId').value = '';

}; 


// custom Script
function GetAssignmentForCompletetion() {
    var obj = {};
    $.ajax({
        type: "POST",
        data: JSON.stringify(obj),
        url: "/Services/DataCollection.asmx/GetActiveAssignment",
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: function (response) {
            var Assignment = response.d;
                $('#AssessmentsDiv').append('<h2>' + Assignment.Name + ':' + Assignment.Type + '</h2>');
                $('#AssessmentsDiv').append('<div id="QuestionareDiv" class="col-xs-12" ></div >');


                GetQustionnaireByAssessmentID(Assignment.Id); 
        },
        failure: function (msg) {
            $('#AssessmentsDiv').text(msg);
        }
    });
};
function GetQustionnaireByAssessmentID(AssessmentId) {

    var obj = {};
    obj.AssessmentId = AssessmentId;

    $.ajax({
        type: "POST",
        url: "/Services/DataCollection.asmx/GetQustionnaireByAssessmentId",
        data: JSON.stringify(obj),
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: function (response) {
            var Qustionnaire = response.d;
            $.each(Qustionnaire, function (index, Qustionnaire) {
                                $('#QuestionareDiv').append('<h3>' + Qustionnaire.Name + ':' + Qustionnaire.Type + '</h3>');
                                $('#QuestionareDiv').append('<div id="Qustionnaire_' + Qustionnaire.Id + '" class="col-xs-12" ></div >');
                               GetAllSubsectionByQustionnaireId(Qustionnaire.Id);  
                });
        },
        failure: function (msg) {
            $('#Erroroutput').text(msg);
        }
    });
}
function GetAllSubsectionByQustionnaireId(QustionnaireId) {
    var obj = {};
    obj.QustionnaireId = QustionnaireId;  
    $.ajax({
        type: "POST",
        data: JSON.stringify(obj),
        url: "/Services/DataCollection.asmx/GetAllSubsectionByQustionnaireId",
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: function (response) {
            var Subsection = response.d;
            $.each(Subsection, function (index, Subsection) {
                $('#Qustionnaire_' + QustionnaireId).append('<div class="row">' +
                    '<h4>' + Subsection.Order+'.) ' + Subsection.Name + '</h4>' +
                    '<div id="Subsection_' + Subsection.Id + '" class="col-xs-12" ></div >'+
                    '</dir>');

                    GetAllQuestionsByAllSubsectionId(Subsection.Id);
       
            });
        },
        failure: function (msg) {
            $('#Qustionnaire_' + QustionnaireId).text(msg);
        }
    });
};
function GetAllQuestionsByAllSubsectionId(SubsectionId) {
    var obj = {};
    obj.SubsectionId = SubsectionId;
    $.ajax({
        type: "POST",
        data: JSON.stringify(obj),
        url: "/Services/DataCollection.asmx/GetAllQuestionsByAllSubsectionId",
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: function (response) {
            var Questions = response.d;
            $.each(Questions, function (index, Questions) {
                $('#Subsection_' + SubsectionId).append('' +
                    '<div class="row"><p>' + Questions.Order + '.) ' +'' + Questions.Description + '</p></div>' 
                   );
            });
     
        },
        failure: function (msg) {
            $('#Subsection_' + SubsectionId).text(msg);
        }
    });
};





function GetAllQuestionOverView() {
    var obj = {};
    $.ajax({
        type: "POST",
        data: JSON.stringify(obj),
        url: "/Services/DataCollection.asmx/GetAllQuestionOverView",
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: function (response) {
            var QuestionOverView = response.d;
            //$('#DisplayData').dataTable().fnClearTable();
            //$('#DisplayData').DataTable().destroy();
            $('#DisplayData').empty();
            $('#DisplayData').append('<thead><th>view</th><th>Id</th><th>Qustionnaire</th><th>sOrder</th><th>Subsection</th><th>qOrder</th><th>Questions</th></thead><tbody>');
            $.each(QuestionOverView, function (index, QuestionOverView) {
                $('#DisplayData').append('<tr>' +
                    '<td style="text-align: center"><label onclick="GetQuestionsById(\'' + QuestionOverView.Id + '\');"  class="fa fa-arrow-right" data-toggle="modal" data-target="#QuestionsModals" style="font-weight: 700;color: green;"> Edit </label> | <label style="font-weight: 700;color: red;" class="fa fa-close" onclick="DeleteQuestionOverView(' + QuestionOverView.Id + ')" >Delete</label></td>' +
                    '<td>' + QuestionOverView.Id + '</td>' +
                    '<td>' + QuestionOverView.Qustionnaire + '</td>' +
                    '<td>' + QuestionOverView.sOrder + '</td>' +
                    '<td>' + QuestionOverView.Subsection + '</td>' +
                    '<td>' + QuestionOverView.qOrder + '</td>' +
                    '<td>' + QuestionOverView.Questions + '</td>' +

                    '</tr>');
            }); $('#DisplayData').append('</tbody>');
            $('#DisplayData').append('<tfoot> <tr onclick="ClearQuestionOverView();"><td border="0" style="border:0px;text-align: center;" ><label  class="fa fa-plus" data-toggle="modal" data-target="#QuestionOverViewModals"> Add New </label></td></tr></tfoot>');
            $('i').remove(".fa-refresh");
            $('#DisplayData').dataTable({
                dom: "Bfrtip", buttons: [
                    { extend: "csv", className: "btn-sm" },
                    { extend: "excel", className: "btn-sm" },
                    { extend: "pdfHtml5", className: "btn-sm" },
                    { extend: "print", className: "btn-sm" }],
                destroy: true,
                responsive: true,
                paging: true,
                searching: true
            });
        },
        failure: function (msg) {
            $('#DisplayData').text(msg);
        }
    });
};

//Survey
function GetSurveyDetails() {
    var obj = {};
    $.ajax({
        type: "POST",
        data: JSON.stringify(obj),
        url: "/Services/DataCollection.asmx/GetSurveyDetails",
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: function (response) {
            var SurveyOverView = response.d;
          
            $('#DisplayData').empty();
            $('#DisplayData').append('<thead><th>view</th><th>Id</th><th>Name</th><th>Assessment Name</th></thead><tbody>');
            $.each(SurveyOverView, function (index, SurveyOverView) {
                $('#DisplayData').append('<tr>' +
                    '<td style="text-align: center"><label onclick="GetSurveyById(' + SurveyOverView.Id + ');"  class="fa fa-arrow-right"  hidden=true data-toggle="modal" data-target="#SurveysModals" style="font-weight: 700;color: green;"> Edit </label>  <label style="font-weight: 700;color: red;" class="fa fa-close" onclick="DeleteSurveyById(' + SurveyOverView.Id + ')" >Delete</label></td>' +
                    '<td>' + SurveyOverView.Id + '</td>' +
                    '<td>' + SurveyOverView.Name + '</td>' +
                    //'<td>' + SurveyOverView.Active + '</td>' +
                    //'<td>' + SurveyOverView.IsDeleted + '</td>' +
                    '<td>' + SurveyOverView.AssessgnmentName + '</td>' +
                    
                    '</tr>');
            }); $('#DisplayData').append('</tbody>');
            $('#DisplayData').append('<tfoot><tr onclick="ClearSurveyDetails();"> <td border="0" style="border:0px;text-align: center;" ><label  class="fa fa-plus" data-toggle="modal" data-target="#SurveysModals"> Add New </label></td></tr></tfoot>');
            $('i').remove(".fa-refresh");
            $('#DisplayData').dataTable({
                dom: "Bfrtip", buttons: [
                    { extend: "csv", className: "btn-sm" },
                    { extend: "excel", className: "btn-sm" },
                    { extend: "pdfHtml5", className: "btn-sm" },
                    { extend: "print", className: "btn-sm" }],
                destroy: true,
                responsive: true,
                paging: true,
                searching: true
            });
        },
        failure: function (msg) {
            $('#DisplayData').text(msg);
        }
    });
};

//Survey Questions
function GetSurveyQuestions() {
    var obj = {};
    $.ajax({
        type: "POST",
        data: JSON.stringify(obj),
        url: "/Services/DataCollection.asmx/GetSurveyQuestions",
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: function (response) {
            var SurveyQuestionsOverView = response.d;
            //$('#DisplayData').dataTable().fnClearTable();
            //$('#DisplayData').DataTable().destroy();
            $('#DisplayData').empty();
            $('#DisplayData').append('<thead><th>view</th><th>Id</th><th>Survey Id</th><th>Question</th><th>Rate</th></thead><tbody>');
            $.each(SurveyQuestionsOverView, function (index, SurveyQuestionsOverView) {
                $('#DisplayData').append('<tr>' +
                    '<td style="text-align: center"><label onclick="GetSurveyQuestionById( ' + SurveyQuestionsOverView.Id + ' );"  class="fa fa-arrow-right" data-toggle="modal" data-target="#SurveyQuestionsModal" style="font-weight: 700;color: green;"> Edit </label> | <label style="font-weight: 700;color: red;" class="fa fa-close" onclick="DeleteSurveyQuestion(' + SurveyQuestionsOverView.Id + ')" >Delete</label></td>' +

                    '<td>' + SurveyQuestionsOverView.Id + '</td>' +
                    '<td>' + SurveyQuestionsOverView.SurveyId + '</td>' +
                    '<td>' + SurveyQuestionsOverView.Question + '</td>' +
                    '<td>' + SurveyQuestionsOverView.Rate + '</td>' +               
                    '</tr>');
            }); $('#DisplayData').append('</tbody>');
            $('#DisplayData').append('<tfoot> <tr onclick="ClearSurveyQuestions();"><td border="0" style="border:0px;text-align: center;" ><label  class="fa fa-plus" data-toggle="modal" data-target="#SurveyQuestionsModal"> Add New </label></td></tr></tfoot>');
            $('i').remove(".fa-refresh");
            $('#DisplayData').dataTable({
                dom: "Bfrtip", buttons: [
                    { extend: "csv", className: "btn-sm" },
                    { extend: "excel", className: "btn-sm" },
                    { extend: "pdfHtml5", className: "btn-sm" },
                    { extend: "print", className: "btn-sm" }],
                destroy: true,
                responsive: true,
                paging: true,
                searching: true
            });
        },
        failure: function (msg) {
            $('#DisplayData').text(msg);
        }
    });
};

function GetQuestionOverViewById(QuestionOverViewId) {  
    var obj = {};
    obj._Id = QuestionOverViewId;
    $.ajax({
        type: "POST",
        url: "/Services/DataCollection.asmx/GetQuestionOverViewById",
        data: JSON.stringify(obj),
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: function (response) {
            var QuestionOverView = response.d;
            try {
                document.getElementById('QuestionOverView_Id').innerHTML = QuestionOverView.Id;
                document.getElementById('QuestionOverView_Qustionnaire').value = QuestionOverView.Qustionnaire;
                document.getElementById('QuestionOverView_sOrder').value = QuestionOverView.sOrder;
                document.getElementById('QuestionOverView_Subsection').value = QuestionOverView.Subsection;
                document.getElementById('QuestionOverView_qOrder').value = QuestionOverView.qOrder;
                document.getElementById('QuestionOverView_Questions').value = QuestionOverView.Questions;

            }
            catch (exception) {
            }
        },
        failure: function (msg) {
            $('#Erroroutput').text(msg);
        }
    });
}
function SaveQuestionOverView() {
    var obj = {};
    obj.Id = document.getElementById('QuestionOverView_Id').innerHTML;
    obj.Qustionnaire = document.getElementById('QuestionOverView_Qustionnaire').value;
    obj.sOrder = document.getElementById('QuestionOverView_sOrder').value;
    obj.Subsection = document.getElementById('QuestionOverView_Subsection').value;
    obj.qOrder = document.getElementById('QuestionOverView_qOrder').value;
    obj.Questions = document.getElementById('QuestionOverView_Questions').value;

    $.ajax({
        type: "POST",
        url: "/Services/DataCollection.asmx/SaveQuestionOverView",
        data: "{ _QuestionOverView:" + JSON.stringify(obj) + "}",
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: function (response) {
            var Mess = response.d;
            if (Mess.Message == 'Saved') {
                document.getElementById('QuestionOverView_Id').innerHTML = Mess.Id;
                document.getElementById('QuestionOverViewStatusUpdateMessgae').innerHTML = Mess.Message;
                GetAllQuestionOverView();
            }
        },
        failure: function (msg) {
            document.getElementById('QuestionOverViewStatusUpdateMessgae').innerHTML = msg;
        }
    });
}
function DeleteQuestionOverView(_Id) {
    var obj = {};
    obj._Id = _Id;
    $.ajax({
        type: "POST",
        url: "/Services/DataCollection.asmx/DeleteQuestionOverView",
        data: JSON.stringify(obj),
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: function (response) {
            GetAllQuestionOverView();
        },
        failure: function (msg) {
        }
    });
}
//Delete Survey by ID
function DeleteSurveyById(_Id) {
    var obj = {};
    obj._Id = _Id;
    var x = confirm("Are you sure you want to delete?");
    if (x === true) {
        $.ajax({
            type: "POST",
            url: "/Services/DataCollection.asmx/DeleteSurveyById",
            data: JSON.stringify(obj),
            contentType: "application/json; charset=utf-8",
            dataType: "json",
            success: function (response) {
                GetSurveyDetails();
            },
            failure: function (msg) {
            }
        });
    }
}
function ClearQuestionOverView() {
    document.getElementById('QuestionOverViewStatusUpdateMessgae').innerHTML = '';
    document.getElementById('QuestionOverView_Id').innerHTML = '';
    document.getElementById('QuestionOverView_Qustionnaire').value = '';
    document.getElementById('QuestionOverView_sOrder').value = '';
    document.getElementById('QuestionOverView_Subsection').value = '';
    document.getElementById('QuestionOverView_qOrder').value = '';
    document.getElementById('QuestionOverView_Questions').value = '';

};



//Survey Questions
function SaveSurveyQuestions() {
    var obj = {};
    obj.Id = document.getElementById('SurveyAssessment_Id').innerHTML;
    obj.SurveyId = document.getElementById('SurveyQuestions_SurveyId').value;
    obj.Question = document.getElementById('SurveyQuestions_Question').value;
    obj.Rate = document.getElementById('SurveyQuestions_Rate').value;
 

    $.ajax({
        type: "POST",
        url: "/Services/DataCollection.asmx/SaveSurveyQuestions",
        data: "{ _SurveyQuestions:" + JSON.stringify(obj) + "}",
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: function (response) {
            var SurveyQuestionsSave = response.d;
            if (SurveyQuestionsSave.Message == 'Saved') {
                document.getElementById('SurveyQuestions_Id').innerHTML = SurveyQuestionsSave.Id;
                document.getElementById('SurveysStatusUpdateMessage').innerHTML = SurveyQuestionsSave.Message;           
            }
            GetSurveyQuestions();
        },
        failure: function (msg) {
            document.getElementById('SurveysStatusUpdateMessage').innerHTML = msg;
        }
    });
}

function ClearSurveyDetails() {
    document.getElementById('SurveysStatusUpdateMessage').innerHTML = '';
    document.getElementById('Survey_Id').value = '';
    document.getElementById('Survey_Name').value = '';
    document.getElementById('Survey_Active').value = '';
    document.getElementById('Survey_IsDeleted').value = '';
    document.getElementById('Survey_ActiveAssessgnmentDiv').value = '';


}


function ClearSurveyQuestions() {
    document.getElementById('SurveyQuestionStatusUpdateMessage').innerHTML = '';
    document.getElementById('SurveyQuestions_Id').value = '';
    document.getElementById('SurveyQuestions_SurveyId').value = '';
    document.getElementById('SurveyQuestions_Question').value = '';
    document.getElementById('SurveyQuestions_Rate').value = '';
    document.getElementById('Survey_ActiveAssessgnmentDiv').value = '';

  


}

function SaveSurvey() {
    var obj = {};
 /*   obj.Id = document.getElementById('Survey_Id').innerHTML;*/
    obj.Name = document.getElementById('Survey_Name').value;
    //obj.Active = document.getElementById('Survey_Active').value;
    //obj.IsDeleted = document.getElementById('Survey_IsDeleted').value;
    obj.AssessgnmentId = document.getElementById('Survey_ActiveAssessgnmentId').value;
    $.ajax({
        type: "POST",
        url: "/Services/DataCollection.asmx/SaveSurvey",
        data: "{ _Surveys:" + JSON.stringify(obj) + "}",
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: function (response) {
            var SurveySave = response.d;
            if (SurveySave.Message == 'Saved') {
                document.getElementById('Survey_Id').innerHTML = SurveySave.Id;
                document.getElementById('SurveysStatusUpdateMessage').innerHTML = SurveySave.Message;
            }
            GetSurveyDetails();
        },
        failure: function (msg) {
            document.getElementById('SurveysStatusUpdateMessage').innerHTML = msg;
        }
    });
}

//Delete Survey Question

function DeleteSurveyQuestion(_Id)
{
    var obj = {};
    obj._Id = _Id;
    var x = confirm("Are you sure you want to delete?");
    if (x === true) {
        $.ajax({
            type: "POST",
            url: "/Services/DataCollection.asmx/DeleteSurveyQuestion",
            data: JSON.stringify(obj),
            contentType: "application/json; charset=utf-8",
            dataType: "json",
            success: function (response) {
                GetSurveyQuestions();
            },
            failure: function (msg) {
            }
        });
    }

}


////View Survey Reports
//function SurveyReportViews(_Id) {
//    var obj = {};
//    obj._Id = document.getElementById('Survey_NameId').value;
//    $.ajax({
//        type: "POST",
//        data: JSON.stringify(obj),
//        url: "/Services/DataCollection.asmx/SurveyReportViews",
//        contentType: "application/json; charset=utf-8",
//        dataType: "json",
//        success: function (response) {
//            var SurveyReport = response.d;
//            //$('#DisplayData').dataTable().fnClearTable();
//            //$('#DisplayData').DataTable().destroy();
//            $('#DisplayData').empty();
//            //var aData = SurveyReport;
//            //var aQuestion = aData[0].Question;
//           // var aAnswer = aData[0].Answer;


//            //var dataT = {
//            //    labels: "Answers",
//            //    datasets: [{
//            //        label: 'Answer',
//            //        data: SurveyReport[0].Answer,
//            //        fill: true,
//            //        backgroundColor: ["rgba(54, 162, 235, 0.2)", "rgba(255, 99, 132, 0.2)", "rgba(255, 159, 64, 0.2)", "rgba(255, 205, 86, 0.2)", "rgba(75, 192, 192, 0.2)", "rgba(153, 102, 255, 0.2)", "rgba(201, 203, 207, 0.2)"],
//            //        borderColor: ["rgb(54, 162, 235)", "rgb(255, 99, 132)", "rgb(255, 159, 64)", "rgb(255, 205, 86)", "rgb(75, 192, 192)", "rgb(153, 102, 255)", "rgb(201, 203, 207)"],
//            //        borderWidth: 1
//            //    },
//            //        {
//            //     labels: "Questions",
//            //        label: 'Answer',
//            //            data: SurveyReport[0].Question,
//            //        fill: true,
//            //        backgroundColor: ["rgba(54, 162, 235, 0.2)", "rgba(255, 99, 132, 0.2)", "rgba(255, 159, 64, 0.2)", "rgba(255, 205, 86, 0.2)", "rgba(75, 192, 192, 0.2)", "rgba(153, 102, 255, 0.2)", "rgba(201, 203, 207, 0.2)"],
//            //        borderColor: ["rgb(54, 162, 235)", "rgb(255, 99, 132)", "rgb(255, 159, 64)", "rgb(255, 205, 86)", "rgb(75, 192, 192)", "rgb(153, 102, 255)", "rgb(201, 203, 207)"],
//            //        borderWidth: 1
//            //            }]
//            //};


//            var ctx = $("#myChart").get(0).getContext('2d');
//            var myNewChart = new Chart(ctx, {
//                type: 'bar',
//                data: {
//                    labels: "Answers",
//                    datasets: [{
//                        label: 'Answer',
//                        data: SurveyReport[0].Answer,
//                        fill: true,
//                        backgroundColor: ["rgba(54, 162, 235, 0.2)", "rgba(255, 99, 132, 0.2)", "rgba(255, 159, 64, 0.2)", "rgba(255, 205, 86, 0.2)", "rgba(75, 192, 192, 0.2)", "rgba(153, 102, 255, 0.2)", "rgba(201, 203, 207, 0.2)"],
//                        borderColor: ["rgb(54, 162, 235)", "rgb(255, 99, 132)", "rgb(255, 159, 64)", "rgb(255, 205, 86)", "rgb(75, 192, 192)", "rgb(153, 102, 255)", "rgb(201, 203, 207)"],
//                        borderWidth: 1
//                    },
//                    {
//                        labels: "Questions",
//                        label: 'Answer',
//                        data: SurveyReport[0].Question,
//                        fill: true,
//                        backgroundColor: ["rgba(54, 162, 235, 0.2)", "rgba(255, 99, 132, 0.2)", "rgba(255, 159, 64, 0.2)", "rgba(255, 205, 86, 0.2)", "rgba(75, 192, 192, 0.2)", "rgba(153, 102, 255, 0.2)", "rgba(201, 203, 207, 0.2)"],
//                        borderColor: ["rgb(54, 162, 235)", "rgb(255, 99, 132)", "rgb(255, 159, 64)", "rgb(255, 205, 86)", "rgb(75, 192, 192)", "rgb(153, 102, 255)", "rgb(201, 203, 207)"],
//                        borderWidth: 1
//                    }]
//                }
//            });



//            $('#DisplayData').append('<thead><th>View Survey Reports</th></thead><tbody>');
//            //$.each(SurveyReport, function (index, SurveyReport) {
//            //    $('#DisplayData').append('<tr>' +
//            //        '<td style="text-align: center"><label  class="fa fa-arrow-right" data-toggle="modal" data-target="#SurvyeReportsModal" style="font-weight: 700;color: green;"> View Reports </label> </td>' + //onclick="GetSurveyQuestionById( ' + SurveyQuestionsOverView.Id + ' );"
//            //        '<td>' + SurveyReport.Id + '</td>' +
//            //        '<td>' + SurveyReport.Question + '</td>' +
//            //        '<td>' + SurveyReport.Answer + '</td>' +
//            //        '</tr>');
//            //}); $('#DisplayData').append('</tbody>');
//            //$('#DisplayData').append('<tfoot> <tr onclick="ClearQuestionOverView();"><td border="0" style="border:0px;text-align: center;" ><label  class="fa fa-plus" data-toggle="modal" data-target="#SurveysQuestionsModals"> Add New </label></td></tr></tfoot>');
//            //$('i').remove(".fa-refresh");
//            //$('#DisplayData').dataTable({
//            //dom: "Bfrtip", buttons: [
//            //    { extend: "csv", className: "btn-sm" },
//            //    { extend: "excel", className: "btn-sm" },
//            //    { extend: "pdfHtml5", className: "btn-sm" },
//            //    { extend: "print", className: "btn-sm" }],
//            //destroy: true,
//            //responsive: true,
//            //paging: true,
//            //searching: true

//           // });
//        },
//        failure: function (msg) {
//            $('#DisplayData').text(msg);
//        }
//    });
//}

//View Survey Reports
function SurveyReportViews(_Id) {
    var obj = {};
    obj._Id = document.getElementById('Survey_NameId').value;
    $.ajax({
        type: "POST",
        data: JSON.stringify(obj),
        url: "/Services/DataCollection.asmx/SurveyReportViews",

        contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: function (response) {
            var SurveyReport = response.d;        
            $('#DisplayData').empty();       
            var dataT = {
                labels: SurveyReport[0].Question,
                datasets: [{
                   // labels: "Questions",
                    label: 'Question',
                    data: SurveyReport[0].Question,
                    fill: true,
                    backgroundColor: ["rgba(54, 162, 235, 0.2)", "rgba(255, 99, 132, 0.2)", "rgba(255, 159, 64, 0.2)", "rgba(255, 205, 86, 0.2)", "rgba(75, 192, 192, 0.2)", "rgba(153, 102, 255, 0.2)", "rgba(201, 203, 207, 0.2)"],
                    borderColor: ["rgb(54, 162, 235)", "rgb(255, 99, 132)", "rgb(255, 159, 64)", "rgb(255, 205, 86)", "rgb(75, 192, 192)", "rgb(153, 102, 255)", "rgb(201, 203, 207)"],
                    borderWidth: 1
                },
                {
                    label: 'Answer',
                    data: SurveyReport[0].Answer,// SurveyReport[0].Answer,
                    fill: true,
                    backgroundColor: ["rgba(54, 162, 235, 0.2)", "rgba(255, 99, 132, 0.2)", "rgba(255, 159, 64, 0.2)", "rgba(255, 205, 86, 0.2)", "rgba(75, 192, 192, 0.2)", "rgba(153, 102, 255, 0.2)", "rgba(201, 203, 207, 0.2)"],
                    borderColor: ["rgb(54, 162, 235)", "rgb(255, 99, 132)", "rgb(255, 159, 64)", "rgb(255, 205, 86)", "rgb(75, 192, 192)", "rgb(153, 102, 255)", "rgb(201, 203, 207)"],
                    borderWidth: 1
                 }]
            };
            var ctx = $("#Surveyreport").get(0).getContext('2d');
            var SurveyReportContainer = new Chart(ctx, {
                type: 'bar',
                data: dataT,
                options: {
                    responsive: true,
                    title: { display: true, text: 'Survey Reports' },
                    legend: { position: 'bottom' },
                    scales: {
                        xAxes: [{ gridLines: { display: false }, display: true, scaleLabel: { display: false, labelString: '' } }],
                        yAxes: [{ gridLines: { display: false }, display: true, scaleLabel: { display: false, labelString: '' }, ticks: { stepSize: 50, beginAtZero: true } }]
                    },
                }
            });
        },
        failure: function (msg) {
            $('#DisplayData').text(msg);
        }
    });

};

function ViewSurveyReport() {
    var obj = {};
  
    $.ajax({
        type: "POST",
        data: JSON.stringify(obj),
        url: "/Services/DataCollection.asmx/GetSurveyReportDiv",
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: function (response) {
            var SurveyReport = response.d;
        /*    $('#DisplayData').dataTable().fnClearTable();*/
      /*      $('#DisplayData').DataTable().destroy();*/
            $('#DisplayData').empty();
            $('#DisplayData').append('<thead><th>View Survey</th><th>Survey Id</th><th>Name</th><th>Question</th><th>Number Of Answers</th></thead><tbody>');
            $.each(SurveyReport, function (index, SurveyReport) {
                $('#DisplayData').append('<tr>' +
                    '<td style="text-align: center"><label onclick="GetReportViewById(' + SurveyReport.Id + ');"  class="fa fa-arrow-right" data-toggle="modal" data-target="#SurvyeReportsModal" style="font-weight: 700;color: green;"> View </label> </td>' +


                    '<td>' + SurveyReport.Id + '</td>' +
                    '<td>' + SurveyReport.Name + '</td>' +
                    '<td>' + SurveyReport.Question + '</td>' +
                    '<td>' + SurveyReport.Answer + '</td>' +
               

                    '</tr>');
            }); $('#DisplayData').append('</tbody>');
          
            $('i').remove(".fa-refresh");
            //$('#DisplayData').dataTable({
            //    dom: "Bfrtip", buttons: [
            //        { extend: "csv", className: "btn-sm" },
            //        { extend: "excel", className: "btn-sm" },
            //        { extend: "pdfHtml5", className: "btn-sm" },
            //        { extend: "print", className: "btn-sm" }],
            //    destroy: true,
            //    responsive: true,
            //    paging: true,
            //    searching: true
            //});
        },
        failure: function (msg) {
            $('#DisplayData').text(msg);
        }
    });
};





